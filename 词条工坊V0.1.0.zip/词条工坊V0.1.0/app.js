'use strict';

/* ==================== DOM ==================== */
const codeInput = document.getElementById('codeInput');
const codeView = document.getElementById('codeView');
const codeHl = document.getElementById('codeHl');
const gutterEl = document.getElementById('gutter');
const gutterInner = document.getElementById('gutterInner');
const acPopup = document.getElementById('acPopup');
const errMenu = document.getElementById('errMenu');
const acList = document.getElementById('acList');
const posInfo = document.getElementById('posInfo');
const tokenInfo = document.getElementById('tokenInfo');
const statSeg = document.getElementById('statSeg');
const statErr = document.getElementById('statErr');
const statWarn = document.getElementById('statWarn');
const docDot = document.getElementById('docDot');
const diagList = document.getElementById('diagList');
const diagFilter = document.getElementById('diagFilter');
const cntAll = document.getElementById('cntAll');
const cntErr = document.getElementById('cntErr');
const cntWarn = document.getElementById('cntWarn');
const lexList = document.getElementById('lexList');
const lexFootnote = document.getElementById('lexFootnote');
const lexCount = document.getElementById('lexCount');
const lexSearch = document.getElementById('lexSearch');
const lexAddInput = document.getElementById('lexAddInput');
const lexAddBtn = document.getElementById('lexAddBtn');
const panelLexicon = document.getElementById('panelLexicon');
const panelDiag = document.getElementById('panelDiag');
const dropHint = document.getElementById('dropHint');
const saveDot = document.getElementById('saveDot');
const saveText = document.getElementById('saveText');
const btnThemeCfg = document.getElementById('btnThemeCfg');
const dlgTheme = document.getElementById('dlgTheme');
const themeClose = document.getElementById('themeClose');
const themePresets = document.getElementById('themePresets');
const themeAccent = document.getElementById('themeAccent');
const themeAccentReset = document.getElementById('themeAccentReset');
const fontList = document.getElementById('fontList');
const btnFontImport = document.getElementById('btnFontImport');
const fontFileInput = document.getElementById('fontFileInput');
const bgPreview = document.getElementById('bgPreview');
const btnBgImport = document.getElementById('btnBgImport');
const bgFileInput = document.getElementById('bgFileInput');
const btnBgClear = document.getElementById('btnBgClear');
const btnBgGlass = document.getElementById('btnBgGlass');
const bgTuneRow = document.getElementById('bgTuneRow');
const bgDim = document.getElementById('bgDim');
const bgBlur = document.getElementById('bgBlur');
const projName = document.getElementById('projName');
const btnProjects = document.getElementById('btnProjects');
const projMenu = document.getElementById('projMenu');
const dlgProjName = document.getElementById('dlgProjName');
const projNameInput = document.getElementById('projNameInput');
const projNameOk = document.getElementById('projNameOk');
const projNameClose = document.getElementById('projNameClose');
const panelAlpha = document.getElementById('panelAlpha');
const panelAlphaVal = document.getElementById('panelAlphaVal');
const btnHelp = document.getElementById('btnHelp');
const btnSample = document.getElementById('btnSample');
const btnExportBtn = document.getElementById('btnExportBtn');
const exportMenu = document.getElementById('exportMenu');
const btnExportLex = document.getElementById('btnExportLex');
const btnImportLex = document.getElementById('btnImportLex');
const btnToggleLex = document.getElementById('btnToggleLex');
const btnToggleDiag = document.getElementById('btnToggleDiag');
const modeToggle = document.getElementById('modeToggle');
const dlgHelp = document.getElementById('dlgHelp');
const dlgImport = document.getElementById('dlgImport');
const dlgConfirm = document.getElementById('dlgConfirm');
const importFile = document.getElementById('importFile');
const importInfo = document.getElementById('importInfo');
const confirmTitle = document.getElementById('confirmTitle');
const confirmBody = document.getElementById('confirmBody');
const confirmOk = document.getElementById('confirmOk');
const fileInput = document.getElementById('fileInput');
const toast = document.getElementById('toast');

/* 新功能元素 */
const btnRules = document.getElementById('btnRules');
const btnKeys = document.getElementById('btnKeys');
const dlgRules = document.getElementById('dlgRules');
const dlgKeys = document.getElementById('dlgKeys');
const rulesClose = document.getElementById('rulesClose');
const rulesToggles = document.getElementById('rulesToggles');
const keysList = document.getElementById('keysList');
const keysHint = document.getElementById('keysHint');
const keysReset = document.getElementById('keysReset');
const keysDone = document.getElementById('keysDone');
const keysClose = document.getElementById('keysClose');
const helpKeysTable = document.getElementById('helpKeysTable');
const btnHelpKeys = document.getElementById('btnHelpKeys');
const ebBuilder = document.getElementById('ebBuilder');
const ebSymBtn = document.getElementById('ebSymBtn');
const ebSplit = document.getElementById('ebSplit');
const dlgSplit = document.getElementById('dlgSplit');
const splitInput = document.getElementById('splitInput');
const splitCount = document.getElementById('splitCount');
const splitRun = document.getElementById('splitRun');
const splitList = document.getElementById('splitList');
const splitAdd = document.getElementById('splitAdd');
const splitSelectAll = document.getElementById('splitSelectAll');
const splitClose = document.getElementById('splitClose');
const splitCancel = document.getElementById('splitCancel');
const btnSnaps = document.getElementById('btnSnaps');
const dlgSnaps = document.getElementById('dlgSnaps');
const snapList = document.getElementById('snapList');
const snapClose = document.getElementById('snapClose');
const snapCancel = document.getElementById('snapCancel');
const symMenu = document.getElementById('symMenu');
const dlgBuilder = document.getElementById('dlgBuilder');
const builderClose = document.getElementById('builderClose');
const builderCancel = document.getElementById('builderCancel');
const builderSearch = document.getElementById('builderSearch');
const builderTerms = document.getElementById('builderTerms');
const builderItems = document.getElementById('builderItems');
const builderTargetHint = document.getElementById('builderTargetHint');
const builderAddChoice = document.getElementById('builderAddChoice');
const builderClear = document.getElementById('builderClear');
const builderPreview = document.getElementById('builderPreview');
const builderDiag = document.getElementById('builderDiag');
const builderInsert = document.getElementById('builderInsert');
const helpSymTable = document.getElementById('helpSymTable');
const rulesSymDoc = document.getElementById('rulesSymDoc');

/* ==================== 常量与状态 ==================== */
const LS_KEY = 'lexicode.v1';
const SNAPS_KEY = 'lexicode.snaps.v1';  /* 编辑内容快照（防误清空，最近 10 份） */
const TRASH_KEY = 'lexicode.trash.v1';  /* 已删项目紧急备份（最近 5 个，误删可找回） */
const MAX_AC_ITEMS = 8;
const MAX_LEX_SHOWN = 400;
const SEG_CAP = 24; // 分词 DP 匹配的最大词长

const state = {
  lexicon: new Map(),  // term -> note
  terms: [],           // 排序后的词条数组
  mode: 'segment',     // 'segment' | 'whole'
  theme: 'dark',
  accent: '',          // 自定义强调色（'#rrggbb'），'' = 跟随主题默认
  font: '',            // 编辑器字体 family；'' = 默认等宽
  edSize: 14,          // 编辑器字号 px（10–28，Ctrl+加/减/0 调节）
  panelAlpha: 100,     // 面板不透明度 %（35–100；<100 自动加毛玻璃模糊）
  filter: 'all',
  parsedLines: [],
  problems: [],
  entryCount: 0,
};

let lexSet = new Set();
let lexMaxLen = 1;
let byFirst = new Map();
let lexPatterns = [];     // 通配词条（含“……”）：{ prefix, suffix, raw }，不进 lexSet
const suggCache = new Map();

let PAD_TOP = 12, PAD_LEFT = 18, LINE_H = 24;

/* 测量光标位置用的隐藏元素 */
const measure = document.createElement('div');
measure.style.cssText = 'position:absolute;top:-9999px;left:0;visibility:hidden;white-space:pre;pointer-events:none;';
document.body.appendChild(measure);

/* ==================== 示例数据 ==================== */
const DEMO_LEXICON = `# 示例词库：每行一个词条，Tab 后可附加注释
北京	首都
上海	直辖市
广州
深圳
杭州
南京
大学	高等院校
学院
中学
小学
校区
附属
人民
医院
第一
第二
交通
科技
促进
中国
国际
中心
研究院
实验室
办公室
会议室
有限
责任
公司
集团
管理
委员会
教育
文化
发展
协会
学会
联合会
的
和
与
及`;

const DEMO_CONTENT = `// 语法：[ ] 内为可省略项，{ | } 内为二选一，// 后是注释
// 符号：，。、；：（）【】“” / + - = × ÷ >< …… .　　\\ 为转义符
北京大学
北京[大学]附属中学
{北京|上海}交通大学附属小学
中国[国际]科技促进中心
人民[第一]医院
北京大学，附属中学。
【北京大学】与【国际中心】
“科技公司”、“文化中心”；第一（教育中心）……
2+3=5、4×2÷1><3
北京\\，大学【\\，已转义：括号内不参与校验】
广州大学城
[大学]`;

/* ==================== 工具函数 ==================== */
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function timeNow() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${p(d.getHours())}:${p(d.getMinutes())}`;
}

function stamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}`;
}

/* ==================== 词库索引 ==================== */
function rebuildIndex() {
  lexSet = new Set();
  lexPatterns = [];
  lexMaxLen = 1;
  byFirst = new Map();
  for (const term of state.lexicon.keys()) {
    if (term.includes('……')) {
      const pat = splitPattern(term);
      if (pat) { lexPatterns.push(pat); continue; } /* 通配词条不进精确索引 */
    }
    lexSet.add(term);
    if (term.length > lexMaxLen) lexMaxLen = term.length;
    const ch = term[0];
    let arr = byFirst.get(ch);
    if (!arr) byFirst.set(ch, (arr = []));
    arr.push(term);
  }
  state.terms = [...state.lexicon.keys()].sort((a, b) => a.localeCompare(b, 'zh-Hans-CN', { numeric: true }));
  suggCache.clear();
}

/* ==================== 通配词条（“将……的”） ==================== */
/* “……”可替换为任意文字（可空）：如“将……的”能匹配“将他们的”“将的”。
   要求“……”之前有非空前缀；含通配的词条不进精确索引，单独进 lexPatterns。 */
function splitPattern(term) {
  const idx = term.indexOf('……');
  if (idx <= 0) return null; /* 无“……”或空前缀：按普通词条处理 */
  return { prefix: term.slice(0, idx), suffix: term.slice(idx + 2), raw: term };
}

function patternMatchWhole(text) {
  for (const p of lexPatterns) {
    if (text.length >= p.prefix.length + p.suffix.length &&
        text.startsWith(p.prefix) && text.endsWith(p.suffix)) return true;
  }
  return false;
}

/* 智能分词 DP 用：位置 i 起能匹配通配词条的最长长度（0 = 不匹配）。
   中段取最长以最大化 DP 覆盖，剩余部分由相邻已知词 / 未收录判定处理。 */
function patternMatchAt(text, i) {
  let best = 0;
  for (const p of lexPatterns) {
    if (!text.startsWith(p.prefix, i)) continue;
    const minL = p.prefix.length + p.suffix.length;
    for (let L = text.length - i; L >= minL; L--) {
      if (text.endsWith(p.suffix, i + L)) { if (L > best) best = L; break; }
    }
  }
  return best;
}

/* ==================== 符号规范（国殇规则集 · 第八章） ==================== */
/* 每个符号：cls=高亮类名，name=名称，desc=规则集释义 */
const SYM_SOFT  = { cls: 'soft', name: '软标点', desc: '用于表述句段的连贯性，不会分割语句' };
const SYM_PERIOD = { cls: 'soft', name: '句号', desc: '用于表述语段的结束（非分割），但依旧受到上文影响' };
const SYM_ENUM  = { cls: 'list', name: '顿号', desc: '用于连续或重复的词条或组词连贯性阅读（兼作列表分隔）' };
const SYM_SEMI  = { cls: 'list', name: '分号', desc: '用于选项分割或语句分割，分割语句但依旧受到上文影响' };
const SYM_COLON = { cls: 'soft', name: '冒号', desc: '用于选项的引用或技能的引用' };
const SYM_PAREN = { cls: 'paren', name: '圆括号', desc: '用于条件判断引伸或描述完善' };
const SYM_CARD  = { cls: 'card', name: '方头括号', desc: '用于引用牌名（内容不参与词条校验）' };
const SYM_QUOTE = { cls: 'quote', name: '引号', desc: '用于引用技能或词条与组词' };
const SYM_SLASH = { cls: 'slash', name: '斜杠', desc: '用于交叉引用描述值或结合' };
const SYM_PLUS  = { cls: 'op', name: '加号', desc: '用于数字之间的加法运算（兼作词条分隔）' };
const SYM_MINUS = { cls: 'op', name: '减号', desc: '用于数字之间的减法运算' };
const SYM_EQ    = { cls: 'op', name: '等号', desc: '用于赋值或算式运算' };
const SYM_MUL   = { cls: 'op', name: '乘号', desc: '用于数字或中文数字间的乘法运算' };
const SYM_DIV   = { cls: 'op', name: '除号', desc: '用于数字或中文数字间的除法运算' };
const SYM_ELL   = { cls: 'ellipsis', name: '省略号', desc: '用于表示重复值或省略不必要值' };
const SYM_CMP   = { cls: 'op', name: '比较符', desc: '用于数字或中文数字比较大小（><）' };
const SYM_DOT   = { cls: 'soft', name: '间隔点', desc: '用于表述省略值或数字选项的分割' };

const SYMBOL_DEFS = {
  '，': SYM_SOFT, '。': SYM_PERIOD, '、': SYM_ENUM, '；': SYM_SEMI, '：': SYM_COLON,
  '（': SYM_PAREN, '(': SYM_PAREN, '）': SYM_PAREN, ')': SYM_PAREN,
  '【': SYM_CARD, '】': SYM_CARD,
  '“': SYM_QUOTE, '”': SYM_QUOTE, '"': SYM_QUOTE,
  '/': SYM_SLASH,
  '-': SYM_MINUS, '=': SYM_EQ, '×': SYM_MUL, '÷': SYM_DIV,
  '…': SYM_ELL,
  '>': SYM_CMP, '<': SYM_CMP, '＞': SYM_CMP, '＜': SYM_CMP,
  '.': SYM_DOT,
};

/* 成对符号（参与括号栈）：开括号 → 闭合字符与 frame 类型 */
const OPEN_FRAMES = {
  '（': { close: '）', kind: 'paren' },
  '(': { close: ')', kind: 'paren' },
  '【': { close: '】', kind: 'card' },
};
const CLOSE_FRAMES = {
  '）': { open: '（', kind: 'paren' },
  ')': { open: '(', kind: 'paren' },
  '】': { open: '【', kind: 'card' },
};

function isSymChar(ch) { return !!SYMBOL_DEFS[ch]; }

/* \ 转义：可被转义的字符 = 全部符号与语法字符 */
function isEscapableChar(ch) {
  return isSymChar(ch) || '[]{}|#\\＼'.includes(ch);
}

/* 预扫描一行的转义构造：escLen[i]>0 表示下标 i 起是一个转义构造（占 escLen[i] 个字符） */
function computeEscapes(code) {
  const escLen = new Array(code.length).fill(0);
  const warns = [];
  for (let i = 0; i < code.length; i++) {
    if (code[i] !== '\\' && code[i] !== '＼') continue;
    const next = code[i + 1];
    if (next === undefined) {
      escLen[i] = 1;
      warns.push({ start: i, end: i + 1, code: 'W406', message: '悬空的转义符“\\”：后面没有字符可转义' });
    } else if (isEscapableChar(next)) {
      escLen[i] = 2;
      i++;
    } else {
      escLen[i] = 1;
      warns.push({ start: i, end: i + 2, code: 'W405', message: `无效的转义序列“\\${next}”：转义符只能写在符号前，“${next}”按普通文字处理` });
    }
  }
  return { escLen, warns };
}

/* ==================== 文本规范化 ==================== */
/* 全角符号 1:1 映射为语法字符，保证长度不变、偏移一致 */
const CHAR_MAP = {
  '［': '[', '］': ']', '｛': '{', '｝': '}', '｜': '|',
  '　': ' ', '＋': '+', '・': '·', '＃': '#',
};

function normalizeLine(raw) {
  let out = '';
  for (const ch of raw) out += CHAR_MAP[ch] || ch;
  return out;
}

function isSepChar(ch) {
  return /\s/.test(ch) || ch === '+' || ch === '·' || ch === ',';
}

/* 注释起点：跳过转义构造后，先遇到 // 或行首 / 分隔符后的 # */
function findCommentStart(code, escLen) {
  let i = 0;
  while (i < code.length) {
    if (escLen[i]) { i += escLen[i]; continue; }
    if (code[i] === '/' && code[i + 1] === '/') return i;
    if (code[i] === '#' && (i === 0 || isSepChar(code[i - 1]))) return i;
    i++;
  }
  return -1;
}

/* ==================== 数值豁免 ==================== */
/* 纯数字 / X（变量）/ 中文数字的片段不参与词条校验 */
const NUM_FRAG_RE = /^([0-9]+|[Xx]+|[零一二两三四五六七八九十百千万亿]+)$/;
function isNumFrag(f) { return NUM_FRAG_RE.test(f); }
function numClass(ch) {
  if ((ch >= '0' && ch <= '9') || ch === 'X' || ch === 'x') return 1;
  if ('零一二两三四五六七八九十百千万亿'.includes(ch)) return 2;
  return 0;
}

/* 判断原子是否构成词条内容（用于“词条”计数与空行判断） */
const MEANINGFUL_SYMS = new Set(['paren', 'card', 'quote', 'ellipsis']);
function isMeaningfulAtom(a) {
  if (a.kind === 'word' || a.kind === 'word-err' || a.kind === 'num' || a.kind === 'cardname') return true;
  if (a.kind === 'bracket' || a.kind === 'bracket-err' || a.kind === 'pipe' || a.kind === 'pipe-err' || a.kind === 'pipe-sep') return true;
  if ((a.kind === 'sym' || a.kind === 'sym-err') && MEANINGFUL_SYMS.has(a.cls)) return true;
  return false;
}

/* 行首 / 行尾多余分隔符检查：分隔符与列表符号（、；） */
function isEdgeSepAtom(a) {
  if (a.kind === 'sep' && /[+·,]/.test(a.text)) return true;
  return a.kind === 'sym' && a.cls === 'list';
}

/* ==================== 符号说明表（帮助 / 规则书共用） ==================== */
const SYMBOL_DOCS = [
  ['，', SYM_SOFT.name, SYM_SOFT.desc],
  ['。', SYM_PERIOD.name, SYM_PERIOD.desc],
  ['、', SYM_ENUM.name, SYM_ENUM.desc],
  ['；', SYM_SEMI.name, SYM_SEMI.desc],
  ['：', SYM_COLON.name, SYM_COLON.desc],
  ['（ ）', SYM_PAREN.name, SYM_PAREN.desc],
  ['【 】', SYM_CARD.name, SYM_CARD.desc],
  ['“ ”', SYM_QUOTE.name, SYM_QUOTE.desc],
  ['/', SYM_SLASH.name, SYM_SLASH.desc],
  ['+ - = × ÷', '运算符', '数字间的加、减、赋值与乘除运算（+ 兼作词条分隔）'],
  ['……', SYM_ELL.name, SYM_ELL.desc],
  ['><', SYM_CMP.name, SYM_CMP.desc],
  ['.', SYM_DOT.name, SYM_DOT.desc],
];

function renderSymbolDocs() {
  const rows = SYMBOL_DOCS.map(([sym, name, desc]) =>
    `<tr><td><code>${escapeHtml(sym)}</code></td><td><b>${escapeHtml(name)}</b> · ${escapeHtml(desc)}</td></tr>`
  );
  rows.push('<tr><td><code>\\</code></td><td><b>转义符</b> · 写在符号前使其按普通文字处理，如 <code>\\，</code>；<code>\\\\</code> 表示普通的反斜杠</td></tr>');
  const html = rows.join('');
  if (helpSymTable) helpSymTable.innerHTML = html;
  if (rulesSymDoc) rulesSymDoc.innerHTML = `<table class="syntax-table">${html}</table>`;
}

/* ==================== 符号下拉列表（编辑工具条） ==================== */
/* 列表化安置符号功能：包裹动作 + 全部第八章符号，后续功能直接往里加条目 */
const SYMBOL_MENU = [
  {
    group: '语法结构',
    items: [
      { act: 'wrap', open: '[', close: ']', glyph: '[ ]', cls: 'bracket', name: '可省略项', desc: '方括号内的内容可以省略' },
      { act: 'wrap', open: '{', close: '}', glyph: '{ }', cls: 'bracket', name: '选项组', desc: '花括号内为二选一，用 | 分隔' },
      { act: 'ins', ins: '|', glyph: '|', cls: 'sep', name: '分隔符', desc: '分隔选项组内的可选项' },
      { act: 'comment', glyph: '//', cls: 'comment', name: '注释', desc: '注释 / 取消注释当前行（Ctrl+/）' },
    ],
  },
  {
    group: '包裹选中内容（第八章符号）',
    items: [
      { act: 'wrap', open: '（', close: '）', glyph: '（ ）', cls: 'paren', name: SYM_PAREN.name, desc: SYM_PAREN.desc },
      { act: 'wrap', open: '【', close: '】', glyph: '【 】', cls: 'card', name: SYM_CARD.name, desc: SYM_CARD.desc },
      { act: 'wrap', open: '“', close: '”', glyph: '“ ”', cls: 'quote', name: SYM_QUOTE.name, desc: SYM_QUOTE.desc },
    ],
  },
  {
    group: '插入符号（规则集第八章 · 写入光标处）',
    items: [
      { act: 'ins', ins: '，', glyph: '，', cls: 'soft', name: SYM_SOFT.name, desc: SYM_SOFT.desc },
      { act: 'ins', ins: '。', glyph: '。', cls: 'soft', name: SYM_PERIOD.name, desc: SYM_PERIOD.desc },
      { act: 'ins', ins: '、', glyph: '、', cls: 'list', name: SYM_ENUM.name, desc: SYM_ENUM.desc },
      { act: 'ins', ins: '；', glyph: '；', cls: 'list', name: SYM_SEMI.name, desc: SYM_SEMI.desc },
      { act: 'ins', ins: '：', glyph: '：', cls: 'soft', name: SYM_COLON.name, desc: SYM_COLON.desc },
      { act: 'ins', ins: '（', glyph: '（', cls: 'paren', name: '圆括号（开）', desc: SYM_PAREN.desc },
      { act: 'ins', ins: '）', glyph: '）', cls: 'paren', name: '圆括号（闭）', desc: SYM_PAREN.desc },
      { act: 'ins', ins: '【', glyph: '【', cls: 'card', name: '方头括号（开）', desc: SYM_CARD.desc },
      { act: 'ins', ins: '】', glyph: '】', cls: 'card', name: '方头括号（闭）', desc: SYM_CARD.desc },
      { act: 'ins', ins: '“', glyph: '“', cls: 'quote', name: '引号（开）', desc: SYM_QUOTE.desc },
      { act: 'ins', ins: '”', glyph: '”', cls: 'quote', name: '引号（闭）', desc: SYM_QUOTE.desc },
      { act: 'ins', ins: '/', glyph: '/', cls: 'slash', name: SYM_SLASH.name, desc: SYM_SLASH.desc },
      { act: 'ins', ins: '+', glyph: '+', cls: 'op', name: SYM_PLUS.name, desc: SYM_PLUS.desc },
      { act: 'ins', ins: '-', glyph: '-', cls: 'op', name: SYM_MINUS.name, desc: SYM_MINUS.desc },
      { act: 'ins', ins: '=', glyph: '=', cls: 'op', name: SYM_EQ.name, desc: SYM_EQ.desc },
      { act: 'ins', ins: '×', glyph: '×', cls: 'op', name: SYM_MUL.name, desc: SYM_MUL.desc },
      { act: 'ins', ins: '÷', glyph: '÷', cls: 'op', name: SYM_DIV.name, desc: SYM_DIV.desc },
      { act: 'ins', ins: '>', glyph: '>', cls: 'op', name: '大于', desc: '数字或中文数字比较大小（大于）' },
      { act: 'ins', ins: '<', glyph: '<', cls: 'op', name: '小于', desc: '数字或中文数字比较大小（小于）' },
      { act: 'ins', ins: '……', glyph: '……', cls: 'ellipsis', name: SYM_ELL.name, desc: SYM_ELL.desc },
      { act: 'ins', ins: '.', glyph: '.', cls: 'soft', name: SYM_DOT.name, desc: SYM_DOT.desc },
      { act: 'ins', ins: '\\', glyph: '\\', cls: 'esc', name: '转义符', desc: '写在符号前使其按普通文字处理' },
    ],
  },
  {
    group: '变体（解析器同样识别）',
    items: [
      { act: 'ins', ins: '＼', glyph: '＼', cls: 'esc', name: '转义符（全角）', desc: '全角形式，效果与 \\ 相同' },
      { act: 'ins', ins: '＞', glyph: '＞', cls: 'op', name: '大于（全角）', desc: '全角形式，效果与 > 相同' },
      { act: 'ins', ins: '＜', glyph: '＜', cls: 'op', name: '小于（全角）', desc: '全角形式，效果与 < 相同' },
      { act: 'ins', ins: '(', glyph: '(', cls: 'paren', name: '圆括号（半角）', desc: '半角形式，效果与 （ ） 相同' },
      { act: 'ins', ins: ')', glyph: ')', cls: 'paren', name: '圆括号（半角）', desc: '半角形式，效果与 （ ） 相同' },
      { act: 'ins', ins: '"', glyph: '"', cls: 'quote', name: '直引号', desc: '半角形式，解析时作为引号的开/闭切换' },
    ],
  },
];

function renderSymMenu() {
  if (!symMenu) return;
  const item = (it) => {
    const text = `<span class="drop-glyph ${it.cls}">${escapeHtml(it.glyph)}</span><span class="drop-text"><b>${escapeHtml(it.name)}</b><small>${escapeHtml(it.desc)}</small></span>`;
    if (it.act === 'wrap') {
      return `<button class="drop-item" data-act="wrap" data-open="${escapeHtml(it.open)}" data-close="${escapeHtml(it.close)}">${text}</button>`;
    }
    if (it.act === 'comment') {
      return `<button class="drop-item" data-act="comment">${text}</button>`;
    }
    return `<button class="drop-item" data-act="ins" data-ins="${escapeHtml(it.ins)}">${text}</button>`;
  };
  symMenu.innerHTML = SYMBOL_MENU.map((g) =>
    [`<div class="drop-group">${escapeHtml(g.group)}</div>`, ...g.items.map(item)].join('')
  ).join('');
}

/* ==================== 分词（动态规划，覆盖率优先） ==================== */
function segmentRun(text) {
  const n = text.length;
  const best = new Array(n + 1).fill(null);
  best[0] = { cov: 0, segs: 0, len: 1, word: null, pat: false, prev: -1 };
  const cap = Math.min(lexMaxLen, SEG_CAP);

  const consider = (j, cov, segs, len, word, pat) => {
    const old = best[j];
    if (!old || cov > old.cov ||
      (cov === old.cov && (segs < old.segs ||
        (segs === old.segs && len > old.len)))) {
      best[j] = { cov, segs, len, word, pat, prev: j - len };
    }
  };

  for (let i = 0; i < n; i++) {
    const cur = best[i];
    if (!cur) continue;
    consider(i + 1, cur.cov, cur.segs, 1, null); // 跳过未收录字符
    let maxL = Math.min(cap, n - i);
    for (let L = maxL; L >= 1; L--) {
      const sub = text.slice(i, i + L);
      if (lexSet.has(sub)) consider(i + L, cur.cov + L, cur.segs + 1, L, sub);
    }
    if (lexPatterns.length) {
      const pL = patternMatchAt(text, i);
      if (pL) consider(i + pL, cur.cov + pL, cur.segs + 1, pL, text.slice(i, i + pL), true);
    }
  }

  const pieces = [];
  let j = n;
  while (j > 0 && best[j]) {
    const b = best[j];
    pieces.push({ start: b.prev, len: b.len, word: b.word, pat: !!b.pat });
    j = b.prev;
  }
  pieces.reverse();

  const segs = [];
  for (const p of pieces) {
    const last = segs[segs.length - 1];
    if (!p.word && last && !last.word) {
      /* 数字类片段不与相邻的普通未收录片段合并，便于单独豁免 */
      const cPrev = numClass(text[last.start + last.len - 1]);
      const cCur = numClass(text[p.start]);
      if ((cPrev || cCur) && cPrev !== cCur) segs.push({ start: p.start, len: p.len, word: p.word, pat: !!p.pat });
      else last.len += p.len;
    } else {
      segs.push({ start: p.start, len: p.len, word: p.word, pat: !!p.pat });
    }
  }
  return segs;
}

/* ==================== 相近词条建议 ==================== */
function levenshtein(a, b, max) {
  if (Math.abs(a.length - b.length) > max) return max + 1;
  const m = a.length, n = b.length;
  const prev = new Array(n + 1);
  const cur = new Array(n + 1);
  for (let j = 0; j <= n; j++) prev[j] = j;
  for (let i = 1; i <= m; i++) {
    cur[0] = i;
    let rowMin = i;
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost);
      if (cur[j] < rowMin) rowMin = cur[j];
    }
    if (rowMin > max) return max + 1;
    for (let j = 0; j <= n; j++) prev[j] = cur[j];
  }
  return prev[n];
}

function computeSuggestions(frag, limit) {
  if (!lexSet.size || !frag) return [];
  let candidates;
  if (state.terms.length <= 1500) candidates = state.terms;
  else candidates = byFirst.get(frag[0]) || [];
  const scored = [];
  for (const term of candidates) {
    if (term === frag) continue;
    const dl = Math.abs(term.length - frag.length);
    let d = levenshtein(frag, term, 2);
    if (d <= 2) scored.push({ term, d, dl });
    else if (term.includes(frag) || frag.includes(term)) scored.push({ term, d: 3, dl });
  }
  scored.sort((a, b) => a.d - b.d || a.dl - b.dl || a.term.length - b.term.length || a.term.localeCompare(b.term, 'zh-Hans-CN'));
  const seen = new Set();
  const out = [];
  for (const s of scored) {
    if (seen.has(s.term)) continue;
    seen.add(s.term);
    out.push(s.term);
    if (out.length >= limit) break;
  }
  return out;
}

function suggestionsFor(frag, limit = 3) {
  if (!lexSet.size || !frag) return [];
  const hit = suggCache.get(frag);
  if (hit) return hit.slice(0, limit);
  const res = computeSuggestions(frag, 5);
  suggCache.set(frag, res);
  return res.slice(0, limit);
}

/* ==================== 规则书：诊断开关 ==================== */
const RULES_LS_KEY = 'lexicode.rules.v1';
const RULE_META = [
  { id: 'E101', sev: 'error', label: '未收录片段（智能分词模式下标红）' },
  { id: 'E102', sev: 'error', label: '未收录词条（整词匹配模式下标红）' },
  { id: 'E201', sev: 'error', label: '“[”或“{”未闭合' },
  { id: 'E202', sev: 'error', label: '多余 / 不匹配的右括号' },
  { id: 'E203', sev: 'error', label: '可省略项 [ ] 内容为空' },
  { id: 'E204', sev: 'error', label: '选项组 { } 中存在空选项' },
  { id: 'E207', sev: 'error', label: '“|”用在 { } 选项组之外' },
  { id: 'E401', sev: 'error', label: '“（”“【”或前引号未闭合' },
  { id: 'W301', sev: 'warn', label: '重复词条行' },
  { id: 'W302', sev: 'warn', label: '整行均为可省略项' },
  { id: 'W303', sev: 'warn', label: '选项组内重复选项' },
  { id: 'W304', sev: 'warn', label: '行首 / 行尾多余分隔符' },
  { id: 'W305', sev: 'warn', label: '选项组只有一个选项' },
  { id: 'W306', sev: 'warn', label: '数值豁免：数字 / X / 中文数字不标红（关闭后按未收录处理）' },
  { id: 'W403', sev: 'warn', label: '牌名引用【】为空' },
  { id: 'W404', sev: 'warn', label: '技能引用“”为空' },
  { id: 'W405', sev: 'warn', label: '无效的转义序列（\\ 后不是符号）' },
  { id: 'W406', sev: 'warn', label: '行尾悬空的转义符 \\（后面没有字符）' },
];
let rules = {};

function loadRules() {
  rules = {};
  for (const r of RULE_META) rules[r.id] = true;
  try {
    const saved = JSON.parse(localStorage.getItem(RULES_LS_KEY));
    if (saved && typeof saved === 'object') {
      for (const r of RULE_META) {
        if (typeof saved[r.id] === 'boolean') rules[r.id] = saved[r.id];
      }
    }
  } catch { /* 忽略 */ }
}

function saveRules() {
  try { localStorage.setItem(RULES_LS_KEY, JSON.stringify(rules)); } catch { /* 忽略 */ }
}

function ruleEnabled(id) {
  return rules[id] !== false;
}

function renderRulesToggles() {
  rulesToggles.innerHTML = RULE_META.map((r) =>
    `<div class="rule-row">
      <span class="rule-code">${r.id}</span>
      <span class="rule-label">${escapeHtml(r.label)}</span>
      <span class="rule-sev ${r.sev === 'error' ? 'err' : 'warn'}">${r.sev === 'error' ? '错误' : '警告'}</span>
      <input type="checkbox" data-rule="${r.id}" ${ruleEnabled(r.id) ? 'checked' : ''} title="启用 / 关闭该规则">
    </div>`
  ).join('');
}

/* ==================== 行解析与校验 ==================== */
function parseLine(raw, lineIdx, lineStart) {
  const norm = normalizeLine(raw);
  const atoms = [];
  const problems = [];
  const { escLen, warns: escWarns } = computeEscapes(norm);
  const cIdx = findCommentStart(norm, escLen);
  const code = cIdx === -1 ? norm : norm.slice(0, cIdx);
  const codeEnd = code.length;
  if (cIdx !== -1) atoms.push({ start: cIdx, end: norm.length, text: norm.slice(cIdx), kind: 'comment' });

  const stack = [];
  const topGroups = [];
  let topWords = 0;
  let wordStart = -1;

  const pushProblem = (start, end, codeId, severity, message, extra) => {
    if (!ruleEnabled(codeId)) return;
    problems.push(Object.assign({
      line: lineIdx + 1, col: start + 1,
      start: lineStart + start, end: lineStart + end,
      code: codeId, severity, message,
    }, extra || {}));
  };

  const inQuoteNow = () => stack.length > 0 && stack[stack.length - 1].kind === 'quote';

  const validateRun = (s, e) => {
    const text = code.slice(s, e);
    if (!text) return;
    const inQuote = inQuoteNow();
    if (!lexSet.size && !lexPatterns.length) {
      atoms.push({ start: s, end: e, text, kind: 'word', inQuote });
      return;
    }
    if (lexSet.has(text)) {
      atoms.push({ start: s, end: e, text, kind: 'word', seg: state.mode === 'segment' && e - s < text.length ? null : text, whole: state.mode === 'whole', inQuote });
      return;
    }
    /* 通配词条整段匹配（如“将……的”匹配“将他们的”“将的”） */
    if (lexPatterns.length && patternMatchWhole(text)) {
      atoms.push({ start: s, end: e, text, kind: 'word', seg: text, whole: state.mode === 'whole', pat: true, inQuote });
      return;
    }
    /* 数值豁免：数字 / X（变量）/ 中文数字不参与词条校验 */
    if (ruleEnabled('W306') && isNumFrag(text)) {
      atoms.push({ start: s, end: e, text, kind: 'num', inQuote });
      return;
    }
    /* 对应规则被关闭时：不再标红，也不产生诊断 */
    if (!ruleEnabled(state.mode === 'whole' ? 'E102' : 'E101')) {
      atoms.push({ start: s, end: e, text, kind: 'word', inQuote });
      return;
    }
    if (state.mode === 'whole') {
      atoms.push({ start: s, end: e, text, kind: 'word-err', inQuote });
      pushProblem(s, e, 'E102', 'error', `未收录词条「${text}」`, { suggestions: suggestionsFor(text) });
      return;
    }
    const segs = segmentRun(text);
    let i = s;
    for (const seg of segs) {
      const end = i + seg.len;
      if (seg.word) {
        atoms.push({ start: i, end, text: seg.word, kind: 'word', seg: seg.word, pat: !!seg.pat, inQuote });
      } else {
        const frag = code.slice(i, end);
        if (ruleEnabled('W306') && isNumFrag(frag)) {
          atoms.push({ start: i, end, text: frag, kind: 'num', inQuote });
        } else {
          atoms.push({ start: i, end, text: frag, kind: 'word-err', inQuote });
          pushProblem(i, end, 'E101', 'error', `未收录片段「${frag}」`, { suggestions: suggestionsFor(frag) });
        }
      }
      i = end;
    }
  };

  const flushWord = (end) => {
    if (wordStart < 0) return;
    const s = wordStart;
    wordStart = -1;
    if (stack.length === 0) topWords++;
    validateRun(s, end);
  };

  const closeFrame = (frame, closeIdx) => {
    frame.close = closeIdx;
    if (frame.kind === 'opt') {
      const inner = code.slice(frame.start + 1, closeIdx);
      if (inner.trim() === '') {
        pushProblem(frame.start, closeIdx + 1, 'E203', 'error', '可省略项 [ ] 的内容为空');
      }
    } else if (frame.kind === 'choice') {
      const branches = frame.branches;
      branches[branches.length - 1].end = closeIdx;
      if (branches.length === 1) {
        pushProblem(frame.start, closeIdx + 1, 'W305', 'warn', '选项组 { } 中只有一个选项，可直接写成词条');
      }
      const seen = new Set();
      for (const b of branches) {
        const t = code.slice(b.start, b.end);
        const s = Math.min(b.start, closeIdx);
        const e = Math.min(Math.max(b.end, s + 1), closeIdx + 1);
        if (t.trim() === '') {
          pushProblem(s, e, 'E204', 'error', '选项组 { } 中存在空选项');
          continue;
        }
        const key = t.replace(/\s+/g, '');
        if (seen.has(key)) pushProblem(b.start, Math.max(b.end, b.start + 1), 'W303', 'warn', `选项「${t.trim()}」重复`);
        else seen.add(key);
      }
    } else if (frame.kind === 'card') {
      /* 【】引用牌名：内容整体不参与词条校验 */
      const inner = code.slice(frame.start + 1, closeIdx);
      if (inner) atoms.push({ start: frame.start + 1, end: closeIdx, text: inner, kind: 'cardname' });
      if (inner.trim() === '') {
        pushProblem(frame.start, closeIdx + 1, 'W403', 'warn', '牌名引用【】里没有内容');
      }
    } else if (frame.kind === 'quote') {
      /* “”引用技能 / 词条：内容照常校验，但允许为空（提示） */
      const inner = code.slice(frame.start + 1, closeIdx);
      if (inner.trim() === '') {
        pushProblem(frame.start, closeIdx + 1, 'W404', 'warn', '技能引用“”里没有内容');
      }
    }
    /* paren（）：允许为空（规则集中（）为待填条件槽，默认值另述） */
  };

  let i = 0;
  while (i < code.length) {
    /* 【 】 牌名引用：内容整体按原文处理，不参与校验 */
    const topFrame = stack[stack.length - 1];
    if (topFrame && topFrame.kind === 'card') {
      if (code[i] === '】') {
        stack.pop();
        closeFrame(topFrame, i);
        atoms.push({ start: i, end: i + 1, text: code[i], kind: 'sym', cls: 'card', name: SYM_CARD.name, desc: SYM_CARD.desc });
        i++;
      } else {
        i += escLen[i] || 1;
      }
      continue;
    }

    /* \ 转义构造：被转义的符号按普通文字处理，不产生符号效果 */
    if (escLen[i]) {
      flushWord(i);
      const len = escLen[i];
      atoms.push({ start: i, end: i + len, text: code.slice(i, i + len), kind: 'esc' });
      i += len;
      continue;
    }

    const ch = code[i];
    if (isSepChar(ch)) {
      flushWord(i);
      let j = i + 1;
      while (j < code.length && isSepChar(code[j])) j++;
      atoms.push({ start: i, end: j, text: code.slice(i, j), kind: 'sep' });
      i = j;
      continue;
    }
    if (ch === '[' || ch === '{') {
      flushWord(i);
      const frame = {
        kind: ch === '[' ? 'opt' : 'choice',
        start: i,
        branches: ch === '{' ? [{ start: i + 1, end: -1 }] : null,
      };
      if (stack.length === 0) topGroups.push(frame);
      stack.push(frame);
      atoms.push({ start: i, end: i + 1, text: ch, kind: 'bracket' });
      i++;
      continue;
    }
    if (ch === ']' || ch === '}') {
      flushWord(i);
      const want = ch === ']' ? 'opt' : 'choice';
      const frame = stack[stack.length - 1];
      if (!frame || frame.kind !== want) {
        pushProblem(i, i + 1, 'E202', 'error',
          ch === ']' ? '多余的“]”，前面没有对应的“[”' : '多余的“}”，前面没有对应的“{”');
        atoms.push({ start: i, end: i + 1, text: ch, kind: 'bracket-err' });
        i++;
        continue;
      }
      stack.pop();
      closeFrame(frame, i);
      atoms.push({ start: i, end: i + 1, text: ch, kind: 'bracket' });
      i++;
      continue;
    }
    if (ch === '|') {
      flushWord(i);
      const frame = stack[stack.length - 1];
      if (frame && frame.kind === 'choice') {
        frame.branches[frame.branches.length - 1].end = i;
        frame.branches.push({ start: i + 1, end: -1 });
        atoms.push({ start: i, end: i + 1, text: ch, kind: 'pipe' });
      } else if (ruleEnabled('E207')) {
        pushProblem(i, i + 1, 'E207', 'error', '“|”只能用在 { } 选项组里');
        atoms.push({ start: i, end: i + 1, text: ch, kind: 'pipe-err' });
      } else {
        /* E207 已关闭：裸 | 视为合法分隔符，外观与 、，一致 */
        atoms.push({ start: i, end: i + 1, text: ch, kind: 'pipe-sep' });
      }
      i++;
      continue;
    }
    /* 圆括号 / 方头括号：条件槽与牌名引用 */
    if (OPEN_FRAMES[ch]) {
      flushWord(i);
      const info = OPEN_FRAMES[ch];
      const frame = { kind: info.kind, start: i, openCh: ch, branches: null };
      if (stack.length === 0) topGroups.push(frame);
      stack.push(frame);
      atoms.push({ start: i, end: i + 1, text: ch, kind: 'sym', cls: SYMBOL_DEFS[ch].cls, name: SYMBOL_DEFS[ch].name, desc: SYMBOL_DEFS[ch].desc });
      i++;
      continue;
    }
    if (CLOSE_FRAMES[ch]) {
      flushWord(i);
      const info = CLOSE_FRAMES[ch];
      const frame = stack[stack.length - 1];
      if (!frame || frame.kind !== info.kind) {
        pushProblem(i, i + 1, 'E202', 'error',
          frame ? `「${ch}」与前面未闭合的「${frame.openCh}」不匹配`
            : `多余的「${ch}」，前面没有对应的「${info.open}」`);
        atoms.push({ start: i, end: i + 1, text: ch, kind: 'sym-err', cls: SYMBOL_DEFS[ch].cls });
        i++;
        continue;
      }
      stack.pop();
      closeFrame(frame, i);
      atoms.push({ start: i, end: i + 1, text: ch, kind: 'sym', cls: SYMBOL_DEFS[ch].cls, name: SYMBOL_DEFS[ch].name, desc: SYMBOL_DEFS[ch].desc });
      i++;
      continue;
    }
    /* 引号（“ ” 与直引号 "）：引用技能 / 词条，成对生效 */
    if (ch === '“' || ch === '”' || ch === '"') {
      flushWord(i);
      const frame = stack[stack.length - 1];
      const opening = ch === '“' || (ch === '"' && (!frame || frame.kind !== 'quote'));
      if (opening) {
        const qf = { kind: 'quote', start: i, openCh: ch, branches: null };
        if (stack.length === 0) topGroups.push(qf);
        stack.push(qf);
        atoms.push({ start: i, end: i + 1, text: ch, kind: 'sym', cls: 'quote', name: SYM_QUOTE.name, desc: SYM_QUOTE.desc });
      } else if (frame && frame.kind === 'quote') {
        stack.pop();
        closeFrame(frame, i);
        atoms.push({ start: i, end: i + 1, text: ch, kind: 'sym', cls: 'quote', name: SYM_QUOTE.name, desc: SYM_QUOTE.desc });
      } else {
        pushProblem(i, i + 1, 'E202', 'error',
          frame ? `「${ch}」与前面未闭合的「${frame.openCh}」不匹配`
            : `多余的「${ch}」，前面没有对应的前引号`);
        atoms.push({ start: i, end: i + 1, text: ch, kind: 'sym-err', cls: 'quote' });
      }
      i++;
      continue;
    }
    /* 其余符号：，。、；：/-=×÷……><. 与全角变体 */
    const sym = SYMBOL_DEFS[ch];
    if (sym) {
      flushWord(i);
      let end = i + 1;
      if (ch === '…') { while (end < code.length && code[end] === '…') end++; }
      else if (ch === '>' || ch === '<' || ch === '＞' || ch === '＜') {
        while (end < code.length && '><＞＜'.includes(code[end])) end++;
      }
      atoms.push({ start: i, end, text: code.slice(i, end), kind: 'sym', cls: sym.cls, name: sym.name, desc: sym.desc });
      i = end;
      continue;
    }
    if (wordStart < 0) wordStart = i;
    i++;
  }
  flushWord(code.length);

  for (const f of stack) {
    if (f.kind === 'opt' || f.kind === 'choice') {
      pushProblem(f.start, f.start + 1, 'E201', 'error',
        f.kind === 'opt' ? '“[”未闭合，缺少“]”' : '“{”未闭合，缺少“}”');
    } else if (f.kind === 'card') {
      pushProblem(f.start, f.start + 1, 'E401', 'error', '“【”未闭合，缺少“】”');
      if (code.length > f.start + 1) {
        atoms.push({ start: f.start + 1, end: code.length, text: code.slice(f.start + 1), kind: 'cardname' });
      }
    } else if (f.kind === 'paren') {
      pushProblem(f.start, f.start + 1, 'E401', 'error', '“（”未闭合，缺少“）”');
    } else {
      pushProblem(f.start, f.start + 1, 'E401', 'error',
        f.openCh === '"' ? '前引号"未闭合，缺少后引号"' : '前引号“未闭合，缺少后引号”');
    }
  }

  /* 无效 / 悬空的转义符 */
  for (const w of escWarns) {
    if (w.start >= codeEnd) continue;
    pushProblem(w.start, Math.min(w.end, codeEnd), w.code, 'warn', w.message);
  }

  let firstCharStart = 0;
  while (firstCharStart < code.length && /\s/.test(code[firstCharStart])) firstCharStart++;
  const hasContent = atoms.some(isMeaningfulAtom);
  const isCommentOnly = !hasContent && cIdx !== -1;

  if (hasContent) {
    /* 整行均为可省略项 */
    if (topWords === 0 && topGroups.length === 1 && topGroups[0].kind === 'opt' && topGroups[0].close != null) {
      pushProblem(topGroups[0].start, topGroups[0].close + 1, 'W302', 'warn', '整行都是可省略项：省略后不剩任何内容');
    }
    /* 行首 / 行尾多余分隔符 */
    const contentAtoms = atoms.filter((a) => a.kind !== 'comment');
    if (contentAtoms.length >= 2) {
      const firstA = contentAtoms[0];
      const lastA = contentAtoms[contentAtoms.length - 1];
      if (isEdgeSepAtom(firstA)) {
        pushProblem(firstA.start, firstA.end, 'W304', 'warn', '行首有多余的分隔符');
      }
      if (isEdgeSepAtom(lastA)) {
        pushProblem(lastA.start, lastA.end, 'W304', 'warn', '行尾有多余的分隔符');
      }
    }
  }

  return { lineIdx, lineStart, norm, code, codeEnd, atoms, problems, firstCharStart, hasContent, isCommentOnly };
}

function analyze() {
  const text = codeInput.value;
  const lines = text.split('\n');
  const parsed = [];
  const problems = [];
  let offset = 0;
  for (let li = 0; li < lines.length; li++) {
    const pl = parseLine(lines[li], li, offset);
    parsed.push(pl);
    problems.push(...pl.problems);
    offset += lines[li].length + 1;
  }
  /* 重复词条行 */
  const seen = new Map();
  for (const pl of parsed) {
    if (!pl.hasContent) continue;
    const key = pl.norm.replace(/\s+/g, '');
    if (key === '') continue;
    if (seen.has(key)) {
      if (ruleEnabled('W301')) {
        const prob = {
          line: pl.lineIdx + 1, col: pl.firstCharStart + 1,
          start: pl.lineStart + pl.firstCharStart,
          end: pl.lineStart + Math.max(pl.codeEnd, pl.firstCharStart + 1),
          code: 'W301', severity: 'warn',
          message: `与第 ${seen.get(key)} 行内容重复`,
        };
        problems.push(prob);
        pl.problems.push(prob); /* 同时挂到行级：行高亮警告点 / 右键行菜单才能看到 */
      }
    } else {
      seen.set(key, pl.lineIdx + 1);
    }
  }
  problems.sort((a, b) => a.start - b.start);
  state.parsedLines = parsed;
  state.problems = problems;
  state.entryCount = parsed.filter((pl) => pl.hasContent).length;
}

/* ==================== 渲染 ==================== */
function renderHighlight() {
  let html = '';
  for (const pl of state.parsedLines) {
    let lineCls = 'hl-line';
    if (pl.hasContent || pl.isCommentOnly) {
      const hasErr = pl.problems.some((p) => p.severity === 'error');
      const hasWarn = !hasErr && pl.problems.some((p) => p.severity === 'warn');
      if (hasErr) lineCls += ' is-err';
      else if (hasWarn) lineCls += ' is-warn';
    }
    let inner = '';
    for (const a of pl.atoms) {
      const t = escapeHtml(a.text);
      switch (a.kind) {
        case 'word': inner += `<span class="tok word${a.seg && state.mode === 'segment' ? ' seg' : ''}${a.pat ? ' pat' : ''}${a.inQuote ? ' in-quote' : ''}">${t}</span>`; break;
        case 'word-err': inner += `<span class="tok err${a.inQuote ? ' in-quote' : ''}">${t}</span>`; break;
        case 'num': inner += `<span class="tok num${a.inQuote ? ' in-quote' : ''}">${t}</span>`; break;
        case 'sep': inner += `<span class="tok sep">${t}</span>`; break;
        case 'bracket': inner += `<span class="tok bracket">${t}</span>`; break;
        case 'bracket-err': inner += `<span class="tok err">${t}</span>`; break;
        case 'pipe': inner += `<span class="tok pipe">${t}</span>`; break;
        case 'pipe-sep': inner += `<span class="tok sep">${t}</span>`; break;
        case 'pipe-err': inner += `<span class="tok err">${t}</span>`; break;
        case 'sym': inner += `<span class="tok sym ${a.cls}">${t}</span>`; break;
        case 'sym-err': inner += `<span class="tok sym ${a.cls} err">${t}</span>`; break;
        case 'esc': inner += `<span class="tok esc">${t}</span>`; break;
        case 'cardname': inner += `<span class="tok cardname">${t}</span>`; break;
        case 'comment': inner += `<span class="tok comment">${t}</span>`; break;
        default: inner += t;
      }
    }
    html += `<div class="${lineCls}">${inner}</div>`;
  }
  codeHl.innerHTML = html;
}

function renderGutter() {
  const n = state.parsedLines.length;
  const digits = String(n).length;
  gutterEl.style.width = `${Math.max(2, digits) + 4}ch`;
  let html = '';
  for (let i = 0; i < n; i++) {
    const pl = state.parsedLines[i];
    const scoped = (pl.hasContent || pl.isCommentOnly) ? pl.problems : [];
    const hasErr = scoped.some((p) => p.severity === 'error');
    const hasWarn = !hasErr && scoped.some((p) => p.severity === 'warn');
    html += `<div class="gutter-line${hasErr ? ' is-err' : hasWarn ? ' is-warn' : ''}" data-line="${i}"><span class="gutter-num">${i + 1}</span><span class="gutter-dot"></span></div>`;
  }
  gutterInner.innerHTML = html;
}

function renderDiagnostics() {
  const errs = state.problems.filter((p) => p.severity === 'error');
  const warns = state.problems.filter((p) => p.severity === 'warn');
  cntAll.textContent = state.problems.length;
  cntErr.textContent = errs.length;
  cntWarn.textContent = warns.length;

  let html = '';
  if (!lexSet.size) {
    html += `<div class="diag-notice">词库为空：请先在左侧导入 TXT 或直接添加词条，否则无法校验词条。</div>`;
  }
  const list = state.problems.filter((p) => state.filter === 'all' || p.severity === state.filter);
  if (!list.length) {
    if (lexSet.size) {
      html += `<div class="diag-empty">
        <div class="big">✓</div>
        <b>全部通过</b>
        <span>没有发现错误或警告</span>
      </div>`;
    }
  } else {
    for (const p of list) {
      const sev = p.severity === 'error' ? 'sev-err' : 'sev-warn';
      let suggHtml = '';
      if (p.suggestions && p.suggestions.length) {
        const chips = p.suggestions
          .map((s) => `<button class="sugg-chip" data-start="${p.start}" data-end="${p.end}" data-term="${escapeHtml(s)}">${escapeHtml(s)}</button>`)
          .join('');
        suggHtml = `<div class="diag-hint"><span>试试：</span>${chips}</div>`;
      }
      html += `<div class="diag-item ${sev}" data-start="${p.start}" data-end="${p.end}" title="点击跳转">
        <div class="diag-meta"><span class="sev-tag">${p.severity === 'error' ? '错误' : '警告'}</span><span>${p.code}</span><span>行 ${p.line}，列 ${p.col}</span></div>
        <div class="diag-msg">${escapeHtml(p.message)}</div>
        ${suggHtml}
      </div>`;
    }
  }
  diagList.innerHTML = html;
}

function renderStatus() {
  const errs = state.problems.filter((p) => p.severity === 'error').length;
  const warns = state.problems.length - errs;
  statSeg.textContent = `词条 ${state.entryCount}`;
  statErr.textContent = `错误 ${errs}`;
  statWarn.textContent = `警告 ${warns}`;
  docDot.className = 'doc-dot' + (errs ? ' err' : warns ? ' warn' : '');
}

function updateActiveLine() {
  const pos = codeInput.selectionStart;
  const text = codeInput.value;
  let idx = 0;
  for (let i = 0; i < pos; i++) if (text.charCodeAt(i) === 10) idx++;
  if (updateActiveLine.last === idx) return;
  const prev = updateActiveLine.last;
  updateActiveLine.last = idx;
  if (prev >= 0 && codeHl.children[prev]) codeHl.children[prev].classList.remove('is-active');
  if (prev >= 0 && gutterInner.children[prev]) gutterInner.children[prev].classList.remove('is-active');
  if (codeHl.children[idx]) codeHl.children[idx].classList.add('is-active');
  if (gutterInner.children[idx]) gutterInner.children[idx].classList.add('is-active');
}

function updateCaretInfo() {
  const pos = codeInput.selectionStart;
  const text = codeInput.value;
  let line = 1, lastNl = -1;
  for (let i = 0; i < pos && i < text.length; i++) {
    if (text.charCodeAt(i) === 10) { line++; lastNl = i; }
  }
  const col = pos - lastNl;
  posInfo.textContent = `行 ${line}，列 ${col}`;

  let info = '';
  const pl = state.parsedLines[line - 1];
  if (pl) {
    const off = pos - pl.lineStart;
    let a = null;
    for (const at of pl.atoms) {
      if (off >= at.start && off < at.end) { a = at; break; }
    }
    if (!a) {
      for (let k = pl.atoms.length - 1; k >= 0; k--) {
        const at = pl.atoms[k];
        if (at.end === off && (at.kind === 'word' || at.kind === 'word-err')) { a = at; break; }
      }
    }
    if (a) {
      switch (a.kind) {
        case 'word': {
          if (!lexSet.size) info = '词库为空，暂不校验词条';
          else if (a.seg) {
            const note = state.lexicon.get(a.seg);
            info = `词条「${a.seg}」已收录${note ? ' · ' + note : ''}${a.inQuote ? ' · 引用' : ''}`;
          } else info = `「${a.text}」已收录${a.inQuote ? ' · 引用' : ''}`;
          break;
        }
        case 'word-err': {
          const sugg = suggestionsFor(a.text);
          info = `未收录「${a.text}」${sugg.length ? ' · 相近：' + sugg.join('、') : ''}`;
          break;
        }
        case 'num': info = '数值（数字 / X / 中文数字，不参与词条校验）'; break;
        case 'bracket': info = a.text === '[' ? '可省略项：方括号内的内容可以省略' : '选项组：花括号内的内容按“|”二选一'; break;
        case 'bracket-err': info = '括号不匹配'; break;
        case 'pipe': info = '选项分隔符'; break;
        case 'pipe-sep': info = '分隔符（“|”用在 { } 外的检查已关闭）'; break;
        case 'pipe-err': info = '“|”只能用于 { } 选项组内'; break;
        case 'sym': info = `「${a.text}」${a.name}：${a.desc}`; break;
        case 'sym-err': info = '括号不匹配'; break;
        case 'esc': info = a.text.length > 1
          ? `转义：${a.text.slice(1)} 按普通文字处理（不作为符号）`
          : '悬空的转义符“\\”';
          break;
        case 'cardname': info = '牌名引用【】：内容不参与词条校验'; break;
        case 'comment': info = '注释（不参与校验）'; break;
        case 'sep': info = a.text.trim() === '+' ? '加法运算符，兼作词条分隔' : '分隔符'; break;
      }
    }
  }
  tokenInfo.textContent = info;
}

/* ==================== 编辑器内拖放移动（按行数落点） ====================
 * 输入层文字透明（color:transparent），Chrome 的拖拽幽灵图按选区实际渲染 → 全透明，
 * 用户看不到自己拖的是什么；且原生落点按「字符」插入，多行词条块会插进别的词条
 * 中间、行结构被打乱——表现为「拖选中的文字不按行数移动」。
 * 这里接管编辑器内的自拖自放：
 *  1) dragstart 生成可见幽灵图（真实显示被拖的词条行）；
 *  2) dragover 把落点吸附到行边界（上半行→该行之前，下半行→下一行之前），并显示落点标线；
 *  3) drop 整块按行移动，保持「一行一个词条」的结构。
 * 外部拖入（从别处拖文本进来）不走此逻辑，保持原生插入。 */
let selfDrag = null;      // 本次自拖动：{ s, e, i, j }
let dragGhostEl = null;

function editorLineStarts(v) {
  const starts = [0];
  for (let i = 0; i < v.length; i++) if (v.charCodeAt(i) === 10) starts.push(i + 1);
  return starts;
}

/* 偏移 → 0 基行号（starts 为 editorLineStarts 结果，二分） */
function editorLineIndexOf(starts, off) {
  let lo = 0, hi = starts.length - 1;
  while (lo < hi) {
    const mid = (lo + hi + 1) >> 1;
    if (starts[mid] <= off) lo = mid; else hi = mid - 1;
  }
  return lo;
}

/* clientY → 落点行边界：{ k, valid }，k = 插到 0 基第 k 行之前（k=总行数 → 末尾）。
   词条=行：拖动的块按整行计（i..j 为选区触及的行）；落进自身块中间会拆坏词条 → 不允许；
   落回块边界（原地）= 保持不动。 */
function dragDropBoundaryAt(ta, clientY, self) {
  const v = ta.value;
  const starts = editorLineStarts(v);
  const n = starts.length;
  const r = ta.getBoundingClientRect();
  const cy = clientY - r.top - PAD_TOP + ta.scrollTop;
  let m = Math.floor(cy / LINE_H);
  if (m < 0) m = 0;
  if (m > n - 1) m = n - 1;
  const k = (cy - m * LINE_H < LINE_H / 2) ? m : m + 1;
  const invalid = k > self.i && k <= self.j;
  return { k, valid: !invalid };
}

function setupEditorDrag(ta) {
  const wrap = ta.parentElement;   /* .code-wrap */
  const ind = document.createElement('div');
  ind.className = 'drag-line-indicator';
  ind.hidden = true;
  wrap.appendChild(ind);
  const hideInd = () => { ind.hidden = true; };

  ta.addEventListener('dragstart', (e) => {
    const sPos = ta.selectionStart, ePos = ta.selectionEnd;
    if (sPos === ePos) { selfDrag = null; return; }
    const v = ta.value;
    const starts = editorLineStarts(v);
    const i = editorLineIndexOf(starts, sPos);
    const j = editorLineIndexOf(starts, Math.max(sPos, ePos - 1));
    /* 词条=行：把选区扩到整行（拖几个字=拖这一整条词条），预览与落点都按整行 */
    const blockEnd = j + 1 < starts.length ? starts[j + 1] : v.length;
    const block = v.slice(starts[i], blockEnd);
    const ls = block.replace(/\n$/, '').split('\n');
    const ghost = document.createElement('div');
    ghost.className = 'drag-ghost';
    ghost.textContent = ls.slice(0, 3).join('\n') + (ls.length > 3 ? `\n…（共 ${ls.length} 行）` : '');
    document.body.appendChild(ghost);
    try { e.dataTransfer.setDragImage(ghost, 24, 12); } catch (_) { /* 旧内核忽略 */ }
    e.dataTransfer.setData('text/plain', block);
    e.dataTransfer.effectAllowed = 'copyMove';
    dragGhostEl = ghost;
    selfDrag = { s: sPos, e: ePos, i, j };
  });

  ta.addEventListener('dragenter', (e) => { if (selfDrag) e.preventDefault(); });

  ta.addEventListener('dragover', (e) => {
    if (!selfDrag) return;   /* 外部拖入 → 保持原生 */
    e.preventDefault();
    const drop = dragDropBoundaryAt(ta, e.clientY, selfDrag);
    if (!drop.valid) {
      e.dataTransfer.dropEffect = 'none';
      hideInd();
      return;
    }
    e.dataTransfer.dropEffect = 'move';
    const n = editorLineStarts(ta.value).length;
    ind.style.top = (PAD_TOP + drop.k * LINE_H - ta.scrollTop) + 'px';
    ind.dataset.label = drop.k >= n ? '移到末尾' : `插到第 ${drop.k + 1} 行前`;
    ind.hidden = false;
  });

  ta.addEventListener('dragleave', hideInd);

  ta.addEventListener('drop', (e) => {
    const ds = selfDrag;
    selfDrag = null;
    hideInd();
    if (!ds) return;   /* 外部拖入 → 原生插入 */
    e.preventDefault();
    const drop = dragDropBoundaryAt(ta, e.clientY, ds);
    if (!drop.valid) return;   /* 落回原地 / 落进自身块 → 什么都不动 */
    const v = ta.value;
    const starts = editorLineStarts(v);
    const i = editorLineIndexOf(starts, ds.s);
    const j = editorLineIndexOf(starts, Math.max(ds.s, ds.e - 1));
    /* 整块按行移动：数组 splice 后 join 可保证除顺序外一字不丢 */
    const lines = v.split('\n');
    const count = j - i + 1;
    const moved = lines.splice(i, count);
    const at = drop.k > j ? drop.k - count : drop.k;
    lines.splice(at, 0, ...moved);
    const newText = lines.join('\n');
    let caret = 0;
    for (let q = 0; q < at; q++) caret += lines[q].length + 1;
    const oldScroll = ta.scrollTop;
    ta.focus();
    ta.value = newText;
    ta.setSelectionRange(caret, caret);
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    ta.scrollTop = oldScroll;
    if (ta === codeInput) syncScroll();
  });

  ta.addEventListener('dragend', () => {
    selfDrag = null;
    hideInd();
    if (dragGhostEl) { dragGhostEl.remove(); dragGhostEl = null; }
  });
}

function syncScroll() {
  codeView.scrollTop = codeInput.scrollTop;
  codeView.scrollLeft = codeInput.scrollLeft;
  gutterInner.style.transform = `translateY(${-codeInput.scrollTop}px)`;
}

function renderAll() {
  renderHighlight();
  renderGutter();
  renderDiagnostics();
  renderStatus();
  syncScroll();
  updateActiveLine.last = -1;
  updateActiveLine();
  updateCaretInfo();
}

let analyzeTimer = 0;
function scheduleAnalyze(delay = 90) {
  clearTimeout(analyzeTimer);
  analyzeTimer = setTimeout(() => {
    analyze();
    renderAll();
  }, delay);
}

/* ==================== 选中与跳转 ==================== */
function applySelection(start, end) {
  codeInput.focus();
  codeInput.setSelectionRange(start, end);
  updateCaretInfo();
  updateActiveLine();
}

function scrollToOffset(offset) {
  const text = codeInput.value;
  let line = 0;
  for (let i = 0; i < offset && i < text.length; i++) {
    if (text.charCodeAt(i) === 10) line++;
  }
  const target = Math.max(0, line * LINE_H - codeInput.clientHeight / 2 + LINE_H);
  codeInput.scrollTop = target;
  syncScroll();
}

function markActiveDiag(start) {
  diagList.querySelectorAll('.diag-item.is-active').forEach((el) => el.classList.remove('is-active'));
  const el = diagList.querySelector(`.diag-item[data-start="${start}"]`);
  if (el) el.classList.add('is-active');
}

/* 跳转到诊断时让目标行闪烁提示 */
function flashEditorLine(offset) {
  const lines = state.parsedLines;
  let idx = 0;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].lineStart <= offset) idx = i; else break;
  }
  const el = codeHl.children[idx];
  if (!el) return;
  el.classList.remove('flash');
  void el.offsetWidth; /* 强制重排以重置动画 */
  el.classList.add('flash');
}

function jumpTo(p) {
  applySelection(p.start, p.end);
  scrollToOffset(p.start);
  markActiveDiag(p.start);
  flashEditorLine(p.start);
}

function jumpRelative(dir) {
  const sorted = state.problems;
  if (!sorted.length) return;
  const pos = codeInput.selectionStart;
  let idx = -1;
  if (dir > 0) {
    idx = sorted.findIndex((p) => p.start > pos);
    if (idx === -1) idx = 0;
  } else {
    for (let i = sorted.length - 1; i >= 0; i--) {
      if (sorted[i].start < pos) { idx = i; break; }
    }
    if (idx === -1) idx = sorted.length - 1;
  }
  jumpTo(sorted[idx]);
}

/* ==================== 自动补全 ==================== */
const acState = { open: false, items: [], active: 0, fragStart: 0, fragEnd: 0 };
let composing = false;

function findAtomAt(pl, off, preferWordEnd) {
  let a = null;
  for (const at of pl.atoms) {
    if (off >= at.start && off < at.end) { a = at; break; }
  }
  if (!a && preferWordEnd) {
    for (let k = pl.atoms.length - 1; k >= 0; k--) {
      const at = pl.atoms[k];
      if (at.end === off && (at.kind === 'word' || at.kind === 'word-err')) { a = at; break; }
    }
  }
  return a;
}

function computeAcItems(frag) {
  const out = [];
  const seen = new Set();
  const push = (term, score) => {
    if (seen.has(term) || term === frag) return;
    seen.add(term);
    out.push({ term, note: state.lexicon.get(term) || '', score });
  };
  let extended = 0;
  for (const term of state.terms) {
    if (term.includes('……')) continue; /* 通配词条不适合直接插入正文 */
    if (term.length > frag.length && term.startsWith(frag)) {
      push(term, 0);
      if (++extended >= MAX_AC_ITEMS) break;
    }
  }
  if (!out.length) {
    for (const s of suggestionsFor(frag, MAX_AC_ITEMS)) push(s, 1);
  }
  out.sort((a, b) => a.score - b.score || a.term.length - b.term.length);
  return out.slice(0, MAX_AC_ITEMS);
}

function caretCoords(pos) {
  const text = codeInput.value;
  const before = text.slice(0, pos);
  let lineIdx = 0;
  for (let i = 0; i < before.length; i++) if (before.charCodeAt(i) === 10) lineIdx++;
  const lineText = before.slice(before.lastIndexOf('\n') + 1);
  measure.textContent = lineText;
  const w = measure.getBoundingClientRect().width;
  const rect = codeInput.getBoundingClientRect();
  const x = rect.left + PAD_LEFT + w - codeInput.scrollLeft;
  const caretTop = rect.top + PAD_TOP + lineIdx * LINE_H - codeInput.scrollTop;
  return { x, caretTop, below: caretTop + LINE_H };
}

/* 可视视口高度：手机横屏或软键盘弹出时 window.innerHeight 比"真正可视区"大，
   浏览器工具条会盖住底部；visualViewport 才是用户实际看得见的区域 */
function viewportH() {
  const vv = window.visualViewport;
  return Math.round((vv && vv.height) || window.innerHeight);
}

/* fixed 元素真实包含块的原点（视口坐标）：祖先带 transform / filter / backdrop-filter /
   perspective / will-change / contain 时，fixed 不再相对视口定位，而是相对该祖先——
   返回其原点供坐标补偿；正常布局（浮层在 body 直下）恒为 0,0 */
function containingBlockOrigin(el) {
  let node = el.parentElement;
  while (node) {
    const cs = getComputedStyle(node);
    if ((cs.transform && cs.transform !== 'none') ||
        (cs.filter && cs.filter !== 'none') ||
        (cs.backdropFilter && cs.backdropFilter !== 'none') ||
        (cs.perspective && cs.perspective !== 'none') ||
        (cs.willChange && cs.willChange !== 'auto') ||
        (cs.contain && /(paint|layout|strict|content)/.test(cs.contain))) {
      const rc = node.getBoundingClientRect();
      return { left: rc.left, top: rc.top };
    }
    node = node.parentElement;
  }
  return { left: 0, top: 0 };
}

function positionAc() {
  if (!acState.open) return;
  const { x, caretTop, below } = caretCoords(acState.fragEnd);
  const pw = 300;
  const vh = viewportH();
  const ph = acPopup.offsetHeight || Math.min(acState.items.length, MAX_AC_ITEMS) * 29 + 30;
  let left = x, top = below + 5;
  if (left + pw > window.innerWidth - 10) left = Math.max(8, window.innerWidth - pw - 10);
  if (top + ph > vh - 10) { top = caretTop - ph - 6; if (top < 8) top = 8; }
  const org = containingBlockOrigin(acPopup);
  acPopup.style.left = `${Math.round(left - org.left)}px`;
  acPopup.style.top = `${Math.round(top - org.top)}px`;
}

function renderAc() {
  acList.innerHTML = acState.items.map((it, idx) =>
    `<div class="ac-item${idx === acState.active ? ' is-active' : ''}" data-idx="${idx}">` +
    `<span class="ac-term">${escapeHtml(it.term)}</span>` +
    (it.note ? `<span class="ac-note">${escapeHtml(it.note)}</span>` : '') +
    `</div>`
  ).join('');
  const activeEl = acList.children[acState.active];
  if (activeEl) activeEl.scrollIntoView({ block: 'nearest' });
}

function openAc(fragStart, fragEnd, items) {
  if (!items.length) { closeAc(); return; }
  acState.open = true;
  acState.items = items;
  acState.active = 0;
  acState.fragStart = fragStart;
  acState.fragEnd = fragEnd;
  acPopup.hidden = false;
  renderAc();
  positionAc();
}

function closeAc() {
  if (!acState.open && acPopup.hidden) return;
  acState.open = false;
  acPopup.hidden = true;
}

function maybeOpenAc(force) {
  if (composing) return closeAc();
  const pos = codeInput.selectionStart;
  if (pos !== codeInput.selectionEnd) return closeAc();
  const text = codeInput.value;
  const before = text.slice(0, pos);
  const lineIdx = (before.match(/\n/g) || []).length;
  const pl = state.parsedLines[lineIdx];
  if (!pl || !lexSet.size) return closeAc();

  const off = pos - pl.lineStart;
  const ch = text[pos - 1];
  const isWordChar = ch && !isSepChar(ch) && !'[]{}|'.includes(ch);
  if (!isWordChar && !force) return closeAc();

  const atom = findAtomAt(pl, off, true);
  let fragStart = -1, fragEnd = -1, frag = '';

  if (atom && atom.kind === 'word-err') {
    fragStart = pl.lineStart + atom.start;
    fragEnd = pl.lineStart + atom.end;
    frag = atom.text;
  } else if (atom && atom.kind === 'word' && atom.end + pl.lineStart === pos) {
    /* 光标位于已收录词末尾：提示可延伸的更长词条 */
    fragStart = pl.lineStart + atom.start;
    fragEnd = pos;
    frag = atom.text;
  }
  if (fragStart < 0) return closeAc();

  const items = computeAcItems(frag);
  if (!items.length) return closeAc();
  openAc(fragStart, fragEnd, items);
}

let acTimer = 0;
function scheduleAc(delay = 70) {
  clearTimeout(acTimer);
  acTimer = setTimeout(() => maybeOpenAc(false), delay);
}

function moveAc(d) {
  if (!acState.items.length) return;
  acState.active = (acState.active + d + acState.items.length) % acState.items.length;
  renderAc();
}

function acceptAc(term) {
  const fs = acState.fragStart, fe = acState.fragEnd;
  closeAc();
  codeInput.focus();
  codeInput.setSelectionRange(fs, fe);
  let ok = false;
  try { ok = document.execCommand('insertText', false, term); } catch { ok = false; }
  if (!ok) {
    const v = codeInput.value;
    codeInput.value = v.slice(0, fs) + term + v.slice(fe);
    codeInput.setSelectionRange(fs + term.length, fs + term.length);
    codeInput.dispatchEvent(new Event('input', { bubbles: true }));
  }
}

function execInsert(text) {
  let ok = false;
  try { ok = document.execCommand('insertText', false, text); } catch { ok = false; }
  if (!ok) {
    const s = codeInput.selectionStart, e = codeInput.selectionEnd;
    const v = codeInput.value;
    codeInput.value = v.slice(0, s) + text + v.slice(e);
    const np = s + text.length;
    codeInput.setSelectionRange(np, np);
    codeInput.dispatchEvent(new Event('input', { bubbles: true }));
  }
}

/* ==================== 词库面板 ==================== */
function renderLexicon() {
  const q = lexSearch.value.trim().toLowerCase();
  let html = '';
  let shown = 0;
  for (const term of state.terms) {
    const note = state.lexicon.get(term) || '';
    if (q && !term.toLowerCase().includes(q) && !note.toLowerCase().includes(q)) continue;
    if (shown >= MAX_LEX_SHOWN) break;
    shown++;
    const isPat = term.includes('……');
    html += `<li class="lex-item" data-term="${escapeHtml(term)}" tabindex="0" title="点击插入到编辑器">
      <span class="lex-word">${escapeHtml(term)}</span>
      ${isPat ? '<span class="lex-badge">通配</span>' : ''}
      ${note ? `<span class="lex-note">${escapeHtml(note)}</span>` : ''}
      <span class="lex-actions"><button class="lex-del" title="删除词条">×</button></span>
    </li>`;
  }
  lexList.innerHTML = html || `<li class="lex-empty">${q ? '没有匹配的词条' : '词库为空<br>在上方输入并回车添加，<br>或导入 TXT 词库'}</li>`;
  lexCount.textContent = state.lexicon.size;
  lexFootnote.textContent = state.terms.length > MAX_LEX_SHOWN
    ? `已显示前 ${MAX_LEX_SHOWN} 项，共 ${state.terms.length} 条，可用搜索缩小范围`
    : '';
}

function addTerm(term, note = '') {
  term = term.trim();
  if (!term) return { ok: false, msg: '词条不能为空' };
  if (/\s/.test(term)) return { ok: false, msg: '词条不能包含空格' };
  if (/[[\]{}|#]/.test(term)) return { ok: false, msg: '词条不能包含 [ ] { } | # 等语法字符' };
  if (state.lexicon.has(term)) {
    if (note && note !== state.lexicon.get(term)) {
      state.lexicon.set(term, note);
      afterLexiconChange();
      return { ok: true, msg: `已更新「${term}」的注释` };
    }
    return { ok: false, msg: `词条「${term}」已存在` };
  }
  state.lexicon.set(term, note);
  afterLexiconChange();
  return { ok: true, msg: `已添加「${term}」` };
}

function deleteTerm(term) {
  const note = state.lexicon.get(term);
  state.lexicon.delete(term);
  afterLexiconChange();
  showToast(`已删除「${term}」`, {
    action: '撤销',
    onAction: () => {
      state.lexicon.set(term, note);
      afterLexiconChange();
    },
  });
}

function afterLexiconChange() {
  rebuildIndex();
  renderLexicon();
  scheduleAnalyze(40);
  scheduleSave();
}

function insertTermIntoEditor(term) {
  codeInput.focus();
  const s = codeInput.selectionStart;
  const e = codeInput.selectionEnd;
  const v = codeInput.value;
  const before = v.slice(0, s);
  const after = v.slice(e);
  let prefix = '', suffix = '';
  const prevCh = before.slice(-1);
  const nextCh = after[0];
  if (prevCh && !isSepChar(prevCh) && !'[{|'.includes(prevCh) && !isSymChar(prevCh)) prefix = ' ';
  if (nextCh && !isSepChar(nextCh) && !']}|'.includes(nextCh) && !isSymChar(nextCh)) suffix = ' ';
  codeInput.setSelectionRange(s, e);
  execInsert(prefix + term + suffix);
  scheduleAnalyze(30);
}

/* ==================== 导入 / 导出 ==================== */
function parseLexiconText(txt) {
  const terms = new Map();
  let dup = 0, invalid = 0, comments = 0;
  for (const rawLine of txt.replace(/^\uFEFF/, '').split(/\r\n|\n|\r/)) {
    const line = rawLine.trim();
    if (!line) continue;
    if (line.startsWith('#') || line.startsWith('//')) { comments++; continue; }
    let term = line, note = '';
    const tIdx = line.indexOf('\t');
    if (tIdx !== -1) {
      term = line.slice(0, tIdx);
      note = line.slice(tIdx + 1).trim();
    } else {
      const pIdx = line.indexOf('|');
      if (pIdx !== -1) {
        term = line.slice(0, pIdx);
        note = line.slice(pIdx + 1).trim();
      }
    }
    term = term.trim();
    if (!term) { invalid++; continue; }
    if (/[\s[\]{}#]/.test(term)) { invalid++; continue; }
    if (terms.has(term)) { dup++; continue; }
    terms.set(term, note);
  }
  return { terms, dup, invalid, comments };
}

async function readTextFile(file) {
  const buf = await file.arrayBuffer();
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(buf);
  } catch {
    try { return new TextDecoder('gb18030').decode(buf); }
    catch { return new TextDecoder('utf-8').decode(buf); }
  }
}

async function handleImport(file) {
  if (!file) return;
  let txt;
  try { txt = await readTextFile(file); }
  catch { showToast(`无法读取文件「${file.name}」`); return; }
  const parsed = parseLexiconText(txt);
  if (!parsed.terms.size) {
    showToast('未能从文件中解析出有效词条（每行一个词条）');
    return;
  }
  importFile.textContent = file.name;
  const parts = [`解析到 <b>${parsed.terms.size}</b> 个词条`];
  const notes = [...parsed.terms.values()].filter(Boolean).length;
  if (notes) parts.push(`含注释 ${notes} 条`);
  if (parsed.dup) parts.push(`重复跳过 ${parsed.dup}`);
  if (parsed.invalid) parts.push(`无效忽略 ${parsed.invalid}`);
  if (parsed.comments) parts.push(`注释行 ${parsed.comments}`);
  importInfo.innerHTML = parts.join(' · ');
  dlgImport.showModal();
  const apply = (mode) => {
    if (mode === 'merge') {
      let added = 0;
      for (const [t, n] of parsed.terms) {
        if (!state.lexicon.has(t)) { state.lexicon.set(t, n); added++; }
        else if (n && !state.lexicon.get(t)) state.lexicon.set(t, n);
      }
      afterLexiconChange();
      showToast(`已合并导入：新增 ${added} 个词条`);
    } else if (mode === 'replace') {
      state.lexicon = parsed.terms;
      afterLexiconChange();
      showToast(`已替换词库：共 ${parsed.terms.size} 个词条`);
    }
  };
  dlgImport.addEventListener('close', () => {
    const v = dlgImport.returnValue;
    dlgImport.removeEventListener('close', null);
    if (v === 'merge' || v === 'replace') apply(v);
  }, { once: true });
}

function downloadBlob(filename, blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

function downloadText(filename, text) {
  downloadBlob(filename, new Blob(['\uFEFF' + text], { type: 'text/plain;charset=utf-8' }));
}

/* ==================== 导出文字图片 ==================== */
/* 把一行编辑内容转成“干净”的可读文本（导出文字图片用）：
   去注释（// 与 #）、省略值 [ ] 整段不导出、选项组 { a | b } 转为 a／b、转义符还原为普通文字 */
function cleanLineForImage(raw) {
  const line = normalizeLine(raw);
  const { escLen } = computeEscapes(line);
  const cStart = findCommentStart(line, escLen);
  const limit = cStart >= 0 ? cStart : line.length;
  let out = '';
  let depth = 0; /* 0 普通文字 / 1 在 [ ] 内 / 2 在 { } 内 */
  let i = 0;
  while (i < limit) {
    if (escLen[i]) { /* 转义构造：还原为普通文字 */
      if (line[i + 1] !== undefined) out += line[i + 1];
      i += escLen[i]; continue;
    }
    const ch = line[i];
    if (ch === '[') { depth = 1; i++; continue; }
    if (ch === ']' && depth === 1) { depth = 0; i++; continue; }
    if (ch === '{') { depth = 2; i++; continue; }
    if (ch === '}' && depth === 2) { depth = 0; i++; continue; }
    if (depth === 1) { i++; continue; } /* 省略值：[ ] 内容不导出 */
    if (ch === '|') { if (depth === 2) out += '／'; i++; continue; } /* { } 内转 ／；{ } 外的裸 | 丢弃 */
    out += ch; i++;
  }
  return out.trim();
}

/* 渲染文字图片：当前编辑器字体 + 白底深字，长行自动软换行，2x 渲染保证清晰 */
function renderTextImage(lines) {
  const PAD = 56, FS = 32, LH = 52, MAXW = 1200, DPR = 2;
  const family = getComputedStyle(codeInput).fontFamily || 'sans-serif';
  const cv = document.createElement('canvas');
  let ctx = cv.getContext('2d');
  ctx.font = `500 ${FS}px ${family}`;
  const rows = [];
  for (const line of lines) {
    if (ctx.measureText(line).width <= MAXW) { rows.push(line); continue; }
    let cur = '';
    for (const ch of line) {
      if (cur && ctx.measureText(cur + ch).width > MAXW) { rows.push(cur); cur = ch; }
      else cur += ch;
    }
    if (cur) rows.push(cur);
  }
  const textW = Math.max(...rows.map((r) => ctx.measureText(r).width), 100);
  const w = Math.min(4096, Math.ceil(textW) + PAD * 2);
  const h = rows.length * LH + PAD * 2;
  cv.width = w * DPR;
  cv.height = h * DPR;
  ctx = cv.getContext('2d');
  ctx.scale(DPR, DPR);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, w, h);
  ctx.font = `500 ${FS}px ${family}`;
  ctx.fillStyle = '#2a2620';
  ctx.textBaseline = 'middle';
  rows.forEach((r, idx) => ctx.fillText(r, PAD, PAD + LH / 2 + idx * LH));
  return cv;
}

function exportImage() {
  const outLines = [];
  for (const rawLine of codeInput.value.replace(/\r\n|\r/g, '\n').split('\n')) {
    const clean = cleanLineForImage(rawLine);
    if (clean) outLines.push(clean);
  }
  if (!outLines.length) { showToast('没有可导出的文字（全部是注释或空行）'); return; }
  if (outLines.length > 250) { showToast(`内容过长（${outLines.length} 行），请分段导出（最多 250 行）`); return; }
  const cv = renderTextImage(outLines);
  cv.toBlob((blob) => {
    if (!blob) { showToast('图片生成失败'); return; }
    downloadBlob(`文字图片_${stamp()}.png`, blob);
    showToast(`已导出文字图片：${outLines.length} 行`);
  }, 'image/png');
}

function exportLexicon() {
  if (!state.lexicon.size) { showToast('词库为空，没有可导出的内容'); return; }
  const lines = [];
  for (const term of state.terms) {
    const note = state.lexicon.get(term);
    lines.push(note ? `${term}\t${note}` : term);
  }
  downloadText(`词库_${stamp()}.txt`, lines.join('\n') + '\n');
  showToast(`已导出词库：${lines.length} 个词条`);
}

function exportDoc() {
  const text = codeInput.value;
  if (!text.trim()) { showToast('编辑内容为空，没有可导出的内容'); return; }
  downloadText(`词条_${stamp()}.txt`, text.endsWith('\n') ? text : text + '\n');
  showToast('已导出编辑内容为 TXT');
}

function exportReport() {
  const errs = state.problems.filter((p) => p.severity === 'error');
  const warns = state.problems.filter((p) => p.severity === 'warn');
  const text = codeInput.value;
  const out = [];
  out.push('词条工坊 · 校验报告');
  out.push(`生成时间：${new Date().toLocaleString('zh-Hans-CN', { hour12: false })}`);
  out.push(`校验模式：${state.mode === 'whole' ? '整词匹配' : '智能分词'}`);
  out.push(`统计：词条 ${state.entryCount} · 错误 ${errs.length} · 警告 ${warns.length}`);
  out.push('');
  if (state.problems.length) {
    out.push('='.repeat(46));
    for (const p of state.problems) {
      const ls = text.lastIndexOf('\n', p.start - 1) + 1;
      let le = text.indexOf('\n', p.end);
      if (le === -1) le = text.length;
      const src = text.slice(ls, le).trim();
      const seg = text.slice(p.start, p.end);
      out.push(`[${p.severity === 'error' ? '错误' : '警告'}] ${p.code} · 行 ${p.line}，列 ${p.col}`);
      out.push(`  ${p.message}`);
      if (src) out.push(`  原文：${src}`);
      if (seg && seg !== src) out.push(`  片段：「${seg}」`);
      out.push('');
    }
  } else {
    out.push('✓ 全部通过：没有发现错误或警告');
  }
  downloadText(`校验报告_${stamp()}.txt`, out.join('\n') + '\n');
  showToast(state.problems.length
    ? `已导出校验报告：${errs.length} 错误 · ${warns.length} 警告`
    : '已导出校验报告：全部通过');
}

/* ==================== 保存 / 加载 ==================== */
let saveTimer = 0;
function setSaveState(s) {
  saveDot.dataset.state = s;
  saveText.textContent = s === 'saved' ? `已保存 ${timeNow()}`
    : s === 'editing' ? '正在编辑…'
    : '保存失败（浏览器存储不可用）';
}

function save() {
  try {
    /* 当前项目的「内容 + 词库 + 模式」存项目文件；主题等全局偏好存 prefs */
    localStorage.setItem(projKey(projects.current), JSON.stringify({
      content: codeInput.value,
      lexicon: [...state.lexicon.entries()],
      mode: state.mode,
      ts: Date.now(),
    }));
    persistPrefs();
    pushSnapshot(codeInput.value);
    setSaveState('saved');
  } catch {
    setSaveState('error');
  }
}

/* 快照保险：每次保存滚动保留最近 10 份编辑内容，误删 / 误清空可从“历史”找回 */
function pushSnapshot(content) {
  try {
    const snaps = JSON.parse(localStorage.getItem(SNAPS_KEY) || '[]');
    const last = snaps[snaps.length - 1];
    if (last && last.c === content) return; /* 内容没变不重复占位 */
    snaps.push({ t: Date.now(), c: content, p: projects.current }); /* p=所属项目，找回时不串项目 */
    while (snaps.length > 10) snaps.shift();
    localStorage.setItem(SNAPS_KEY, JSON.stringify(snaps));
  } catch { /* 忽略 */ }
}

function snapshotList() {
  try {
    const all = JSON.parse(localStorage.getItem(SNAPS_KEY) || '[]');
    /* 无 p 标记的旧快照 = 迁移前内容，只在最老的项目（默认项目）里可见 */
    const legacyVisible = projects.list[0] && projects.list[0].id === projects.current;
    return all.filter((s) => (s.p ? s.p === projects.current : legacyVisible)).reverse();
  } catch { return []; }
}

function renderSnaps() {
  const snaps = snapshotList();
  if (!snaps.length) {
    snapList.innerHTML = '<div class="split-empty">还没有历史快照。<br>编辑内容后每次自动保存都会留一份（最近 10 份）。</div>';
    return;
  }
  snapList.innerHTML = snaps.map((s, i) => {
    const d = new Date(s.t);
    const p = (n) => String(n).padStart(2, '0');
    const when = `${d.getMonth() + 1}月${d.getDate()}日 ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
    const first = (s.c.split('\n').find((l) => l.trim()) || '（空）').slice(0, 42);
    return `<button class="snap-item" data-snap-i="${i}" title="点击恢复此快照（恢复前当前内容也会先存一份快照）">
      <span class="snap-when">${when}</span>
      <span class="snap-len">${s.c.length} 字</span>
      <span class="snap-preview">${escapeHtml(first)}</span>
    </button>`;
  }).join('');
}

function restoreSnapshot(i) {
  const snap = snapshotList()[i];
  if (!snap) return;
  pushSnapshot(codeInput.value); /* 恢复前先存当前内容，恢复操作本身可撤销 */
  codeInput.value = snap.c;
  codeInput.dispatchEvent(new Event('input', { bubbles: true }));
  clearTimeout(saveTimer);
  save();
  dlgSnaps.close();
  showToast(`已恢复快照（${snap.c.length} 字，${new Date(snap.t).toLocaleTimeString('zh-Hans-CN')} 的版本）`);
}

function scheduleSave() {
  setSaveState('editing');
  clearTimeout(saveTimer);
  saveTimer = setTimeout(save, 600);
}

/* ==================== 项目（新建 / 删除 / 每项目独立词库） ====================
 * 每个项目独立的「编辑内容 + 词库 + 校验模式」；主题 / 强调色 / 字体 / 字号 / 规则全局共享。
 *   lexicode.projects.v1 = { current: id, list: [{ id, name, ts }] }
 *   lexicode.proj.<id>   = { content, lexicon, mode, ts }
 * 旧 lexicode.v1 首次启动整体迁入默认项目后冻结（永不再改写，留作只读备份）；
 * 全局偏好从 v1 迁到 lexicode.prefs.v1。 */
const PROJ_KEY = 'lexicode.projects.v1';
const PREFS_KEY = 'lexicode.prefs.v1';
const PROJ_LS_PREFIX = 'lexicode.proj.';
let projects = { current: '', list: [] };

function projKey(id) { return PROJ_LS_PREFIX + id; }
function newProjId() { return 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
function readJson(key) { try { return JSON.parse(localStorage.getItem(key)); } catch { return null; } }
function projNameOf(id) { const p = projects.list.find((x) => x.id === id); return p ? p.name : '未知项目'; }

function persistProjects() {
  try { localStorage.setItem(PROJ_KEY, JSON.stringify(projects)); }
  catch (e) { console.warn('项目列表保存失败', e); }
}

/* 载入项目列表；无项目数据时做一次性迁移（旧 lexicode.v1 → 默认项目）。返回是否迁到了旧内容 */
function loadProjects() {
  const saved = readJson(PROJ_KEY);
  if (saved && Array.isArray(saved.list) && saved.list.length) {
    projects = { current: saved.current, list: saved.list };
    if (!projects.list.some((p) => p.id === projects.current)) projects.current = projects.list[0].id;
    return false;
  }
  const legacy = readJson(LS_KEY);
  const id = newProjId();
  let migrated = false;
  if (legacy && Array.isArray(legacy.lexicon)) {
    try {
      localStorage.setItem(projKey(id), JSON.stringify({
        content: typeof legacy.content === 'string' ? legacy.content : '',
        lexicon: legacy.lexicon,
        mode: legacy.mode === 'whole' ? 'whole' : 'segment',
        ts: Date.now(),
      }));
      migrated = true;
    } catch (e) { console.warn('旧数据迁移失败，将以全新项目开始', e); }
  }
  projects = { current: id, list: [{ id, name: '默认项目', ts: Date.now() }] };
  persistProjects();
  return migrated;
}

/* 把当前项目读入 state / 编辑器。返回项目文件是否存在 */
function loadCurrentProject() {
  const data = readJson(projKey(projects.current));
  state.lexicon = new Map();
  if (data && Array.isArray(data.lexicon)) {
    for (const pair of data.lexicon) {
      if (!Array.isArray(pair) || typeof pair[0] !== 'string') continue;
      state.lexicon.set(pair[0], typeof pair[1] === 'string' ? pair[1] : '');
    }
    codeInput.value = typeof data.content === 'string' ? data.content : '';
    if (data.mode === 'whole' || data.mode === 'segment') state.mode = data.mode;
    return true;
  }
  codeInput.value = '';
  return false;
}

/* 全局偏好（主题 / 强调色 / 字体 / 字号）：首次从旧 v1 取，之后存 prefs.v1 */
function loadPrefs() {
  let p = readJson(PREFS_KEY);
  if (!p) p = readJson(LS_KEY) || {};
  if (THEMES.some((t) => t.id === p.theme)) state.theme = p.theme;
  if (typeof p.accent === 'string' && (/^#[0-9a-f]{6}$/i.test(p.accent) || p.accent === '')) state.accent = p.accent;
  if (typeof p.font === 'string') state.font = p.font;
  if (typeof p.edSize === 'number' && p.edSize >= 10 && p.edSize <= 28) state.edSize = Math.round(p.edSize);
  if (typeof p.panelAlpha === 'number') state.panelAlpha = Math.max(35, Math.min(100, Math.round(p.panelAlpha)));
}

function persistPrefs() {
  try { localStorage.setItem(PREFS_KEY, JSON.stringify({ theme: state.theme, accent: state.accent, font: state.font, edSize: state.edSize, panelAlpha: state.panelAlpha })); }
  catch { /* 忽略 */ }
}

function updateProjUi() {
  projName.textContent = projNameOf(projects.current);
  renderProjMenu();
}

function renderProjMenu() {
  projMenu.innerHTML =
    `<div class="drop-group">项目 · 内容与词库各自独立</div>` +
    projects.list.map((p) => `
      <button class="drop-item${p.id === projects.current ? ' is-active' : ''}" data-proj="${p.id}">
        <span class="drop-text"><b>${escapeHtml(p.name)}</b></span>
        ${p.id === projects.current ? '<span class="drop-file">当前</span>' : ''}
      </button>`).join('') +
    `<div class="drop-group">管理</div>
     <button class="drop-item" data-proj-act="new"><span class="drop-text"><b>＋ 新建项目</b><small>空白项目，内容与词库独立</small></span></button>
     <button class="drop-item" data-proj-act="rename"><span class="drop-text"><b>✎ 重命名当前项目</b></span></button>
     <button class="drop-item" data-proj-act="del"><span class="drop-text"><b>🗑 删除当前项目</b><small>内容与词库一并删除，不可撤销</small></span></button>`;
}

/* 切换项目：先落盘当前，再载入目标 */
function switchProject(id) {
  if (!projects.list.some((p) => p.id === id) || id === projects.current) return;
  save();
  closeAc();
  closeErrMenu();
  projects.current = id;
  persistProjects();
  loadCurrentProject();
  codeInput.setSelectionRange(0, 0);
  codeInput.scrollTop = 0;
  setMode(state.mode, true);
  rebuildIndex();
  renderLexicon();
  analyze();
  renderAll();
  updateProjUi();
  showToast(`已切换到「${projNameOf(id)}」`);
}

async function newProject() {
  save();
  closeAc();
  closeErrMenu();
  const id = newProjId();
  const name = `项目 ${projects.list.length + 1}`;
  projects.list.push({ id, name, ts: Date.now() });
  projects.current = id;
  persistProjects();
  try { localStorage.setItem(projKey(id), JSON.stringify({ content: '', lexicon: [], mode: state.mode, ts: Date.now() })); } catch (e) { console.warn(e); }
  loadCurrentProject();
  codeInput.setSelectionRange(0, 0);
  codeInput.scrollTop = 0;
  rebuildIndex();
  renderLexicon();
  analyze();
  renderAll();
  updateProjUi();
  showToast(`已新建「${name}」— 内容与词库独立保存`);
}

/* 删除项目前把整份项目（内容+词库+模式）存入紧急备份，误删可找回 */
function archiveDeletedProject(id, name) {
  try {
    const trash = JSON.parse(localStorage.getItem(TRASH_KEY) || '[]');
    trash.push({
      t: Date.now(), id, name,
      content: codeInput.value,
      lexicon: [...state.lexicon.entries()],
      mode: state.mode,
    });
    while (trash.length > 5) trash.shift();
    localStorage.setItem(TRASH_KEY, JSON.stringify(trash));
  } catch (e) { console.warn('删除备份写入失败（不影响删除本身）', e); }
}

async function deleteProject() {
  if (projects.list.length <= 1) { showToast('至少保留一个项目，不能删除'); return; }
  const id = projects.current;
  const name = projNameOf(id);
  const ok = await openConfirm({
    title: '删除项目',
    body: `确定删除「${name}」？该项目的编辑内容与词库将从列表中移除；删除前会自动留一份紧急备份（最近 5 个），误删可找回。`,
    okText: '删除',
  });
  if (!ok) return;
  archiveDeletedProject(id, name);
  const idx = projects.list.findIndex((p) => p.id === id);
  projects.list.splice(idx, 1);
  try { localStorage.removeItem(projKey(id)); } catch (e) { console.warn('项目记录清除失败', e); }
  projects.current = projects.list[Math.max(0, idx - 1)].id;
  persistProjects();
  loadCurrentProject();
  codeInput.setSelectionRange(0, 0);
  codeInput.scrollTop = 0;
  rebuildIndex();
  renderLexicon();
  analyze();
  renderAll();
  updateProjUi();
  showToast(`已删除「${name}」`);
}

function openProjRename() {
  projNameInput.value = projNameOf(projects.current);
  dlgProjName.showModal();
  requestAnimationFrame(() => { projNameInput.focus(); projNameInput.select(); });
}

function confirmProjRename() {
  const name = projNameInput.value.trim();
  if (!name) { showToast('项目名称不能为空'); return; }
  const p = projects.list.find((x) => x.id === projects.current);
  if (p) p.name = name;
  persistProjects();
  dlgProjName.close();
  updateProjUi();
  showToast(`已重命名为「${name}」`);
}

function loadDemo() {
  state.lexicon = parseLexiconText(DEMO_LEXICON).terms;
  codeInput.value = DEMO_CONTENT;
}

/* ==================== 提示条 ==================== */
let toastTimer = 0;
function showToast(msg, opts = {}) {
  toast.innerHTML = `<span class="toast-msg">${escapeHtml(msg)}</span>` +
    (opts.action ? `<button class="toast-action">${escapeHtml(opts.action)}</button>` : '');
  toast.hidden = false;
  requestAnimationFrame(() => toast.classList.add('show'));
  if (opts.action) {
    toast.querySelector('.toast-action').addEventListener('click', () => {
      hideToast();
      if (opts.onAction) opts.onAction();
    });
  }
  clearTimeout(toastTimer);
  toastTimer = setTimeout(hideToast, opts.duration || 3500);
}

function hideToast() {
  toast.classList.remove('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { toast.hidden = true; }, 200);
}

/* ==================== 确认对话框 ==================== */
function openConfirm(opts) {
  confirmTitle.textContent = opts.title || '确认操作';
  confirmBody.textContent = opts.body || '';
  confirmOk.textContent = opts.okText || '确定';
  confirmOk.className = 'btn ' + (opts.danger === false ? 'btn-primary' : 'btn-danger');
  dlgConfirm.showModal();
  return new Promise((resolve) => {
    dlgConfirm.addEventListener('close', () => resolve(dlgConfirm.returnValue === 'ok'), { once: true });
  });
}

/* ==================== 快捷键自定义 ==================== */
const KEYS_LS_KEY = 'lexicode.keys.v1';
const KEY_ACTIONS = [
  { id: 'save', label: '保存（浏览器本地）', def: 'Ctrl+S' },
  { id: 'import', label: '导入词库 TXT', def: 'Ctrl+O' },
  { id: 'exportDoc', label: '导出编辑内容', def: 'Ctrl+Shift+E' },
  { id: 'exportLex', label: '导出词库', def: '' },
  { id: 'nextProblem', label: '下一条诊断', def: 'F8' },
  { id: 'prevProblem', label: '上一条诊断', def: 'Shift+F8' },
  { id: 'autocomplete', label: '补全建议', def: 'Ctrl+Space' },
  { id: 'toggleComment', label: '注释 / 取消注释', def: 'Ctrl+/' },
  { id: 'builder', label: '词条编辑器', def: 'Ctrl+B' },
  { id: 'split', label: '智能拆词', def: 'Ctrl+I' },
  { id: 'rules', label: '规则书', def: '' },
  { id: 'help', label: '帮助', def: 'F1' },
];
let bindings = {};        // action -> combo（'' 表示未设置）
let capturingAction = null;

function loadBindings() {
  bindings = {};
  for (const a of KEY_ACTIONS) bindings[a.id] = a.def;
  try {
    const saved = JSON.parse(localStorage.getItem(KEYS_LS_KEY));
    if (saved && typeof saved === 'object') {
      for (const a of KEY_ACTIONS) {
        if (typeof saved[a.id] === 'string') bindings[a.id] = saved[a.id];
      }
    }
  } catch { /* 忽略 */ }
}

function saveBindings() {
  try { localStorage.setItem(KEYS_LS_KEY, JSON.stringify(bindings)); } catch { /* 忽略 */ }
}

function comboFromEvent(e) {
  const key = e.key;
  if (!key || ['Control', 'Alt', 'Shift', 'Meta', 'CapsLock', 'NumLock', 'ScrollLock', 'ContextMenu', 'Dead'].includes(key)) return null;
  let k = key;
  if (k === ' ') k = 'Space';
  else if (k.length === 1) k = k.toUpperCase();
  else k = k.replace(/^Arrow/, ''); // ArrowUp -> Up
  const parts = [];
  if (e.ctrlKey) parts.push('Ctrl');
  if (e.altKey) parts.push('Alt');
  if (e.shiftKey) parts.push('Shift');
  if (e.metaKey) parts.push('Meta');
  parts.push(k);
  return parts.join('+');
}

function actionForCombo(combo) {
  if (!combo) return null;
  for (const a of KEY_ACTIONS) {
    if (bindings[a.id] && bindings[a.id].toLowerCase() === combo.toLowerCase()) return a.id;
  }
  return null;
}

function comboLabel(combo) {
  if (!combo) return '未设置';
  return combo
    .split('+')
    .map((p) => (p.length === 1 ? p.toUpperCase() : p))
    .join(' + ');
}

function runAction(id) {
  switch (id) {
    case 'save': clearTimeout(saveTimer); save(); showToast('已保存到浏览器本地'); break;
    case 'import': fileInput.click(); break;
    case 'exportDoc': exportDoc(); break;
    case 'exportLex': exportLexicon(); break;
    case 'nextProblem': jumpRelative(1); break;
    case 'prevProblem': jumpRelative(-1); break;
    case 'autocomplete': maybeOpenAc(true); break;
    case 'toggleComment': toggleComment(); break;
    case 'builder': openBuilder(); break;
    case 'split': openSplit(); break;
    case 'rules': dlgRules.showModal(); break;
    case 'help': dlgHelp.showModal(); break;
  }
}

function findConflict(action, combo) {
  for (const a of KEY_ACTIONS) {
    if (a.id !== action && bindings[a.id] && bindings[a.id].toLowerCase() === combo.toLowerCase()) return a;
  }
  return null;
}

function assignKey(action, combo) {
  const conflict = findConflict(action, combo);
  if (conflict) {
    bindings[conflict.id] = '';
    keysHint.textContent = `组合「${comboLabel(combo)}」原属于「${conflict.label}」，已将其移除`;
    keysHint.classList.add('conflict');
  } else {
    keysHint.textContent = `已设置「${KEY_ACTIONS.find((a) => a.id === action).label}」为 ${comboLabel(combo)}`;
    keysHint.classList.remove('conflict');
  }
  bindings[action] = combo;
  saveBindings();
  renderKeys();
  renderHelpKeys();
}

function renderKeys() {
  keysList.innerHTML = KEY_ACTIONS.map((a) => {
    const capturing = capturingAction === a.id;
    const combo = capturing ? '按下新组合键…' : bindings[a.id];
    return `<div class="key-row" data-action="${a.id}">
      <span class="key-label">${escapeHtml(a.label)}</span>
      <span class="key-combo${capturing ? ' capturing' : combo ? '' : ' empty'}">${escapeHtml(combo)}</span>
      <button class="btn small" data-act="${a.id}" data-mode="${capturing ? 'cancel' : 'edit'}">${capturing ? '取消' : '修改'}</button>
    </div>`;
  }).join('');
}

function renderHelpKeys() {
  helpKeysTable.innerHTML = KEY_ACTIONS
    .filter((a) => bindings[a.id])
    .map((a) => {
      const parts = bindings[a.id].split('+');
      const keys = parts.map((p) => `<kbd>${escapeHtml(p.length === 1 ? p.toUpperCase() : p)}</kbd>`).join('+');
      return `<tr><td>${keys}</td><td>${escapeHtml(a.label)}</td></tr>`;
    })
    .join('');
}

function startCapture(action) {
  capturingAction = action;
  keysHint.textContent = '请按下新的组合键（Esc 取消）';
  keysHint.classList.remove('conflict');
  renderKeys();
}

function cancelCapture() {
  capturingAction = null;
  keysHint.textContent = '';
  renderKeys();
}

/* ==================== 主题 / 模式 ==================== */

/* 预设主题（样式表内 [data-theme=…] 块）；swatch = 卡片预览 [底色, 强调色, 文字色] */
const THEMES = [
  { id: 'dark', name: '深色', dark: true, swatch: ['#121926', '#4fd6c2', '#dbe4f0'] },
  { id: 'light', name: '浅色', dark: false, swatch: ['#ffffff', '#0d9488', '#1f2733'] },
  { id: 'sepia', name: '纸墨', dark: false, swatch: ['#faf4e8', '#b4632d', '#3d3227'] },
  { id: 'oled', name: '曜黑', dark: true, swatch: ['#000000', '#00e0b8', '#e8e8ec'] },
  { id: 'glass', name: '毛玻璃', dark: false, swatch: ['#d9e6f2', '#0d9488', '#1e2a38'] },
];

function themeMeta(id) { return THEMES.find((t) => t.id === id); }

function hexToRgb(hex) {
  const m = /^#?([0-9a-f]{6}|[0-9a-f]{3})$/i.exec(String(hex || '').trim());
  if (!m) return null;
  let h = m[1];
  if (h.length === 3) h = [...h].map((c) => c + c).join('');
  const n = parseInt(h, 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

function rgbToHex({ r, g, b }) {
  const p = (v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0');
  return '#' + p(r) + p(g) + p(b);
}

/* 相对亮度（WCAG），用于决定强调色上的文字用深还是浅 */
function rgbLuminance({ r, g, b }) {
  const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
  return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
}

/* 把自定义强调色写成内联变量，覆盖所有预设主题；'' = 清除恢复默认 */
function applyAccent() {
  const root = document.documentElement;
  const rgb = hexToRgb(state.accent);
  if (!rgb) {
    ['--accent', '--accent-2', '--sel', '--line-active', '--on-accent'].forEach((v) => root.style.removeProperty(v));
    return;
  }
  const k = 0.82; // accent-2 = 略深的强调色
  root.style.setProperty('--accent', rgbToHex(rgb));
  root.style.setProperty('--accent-2', rgbToHex({ r: rgb.r * k, g: rgb.g * k, b: rgb.b * k }));
  root.style.setProperty('--sel', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.22)`);
  root.style.setProperty('--line-active', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.07)`);
  root.style.setProperty('--on-accent', rgbLuminance(rgb) > 0.55 ? '#10241f' : '#ffffff');
}

let themeAnimTimer = 0;
function applyTheme(theme) {
  state.theme = theme;
  const root = document.documentElement;
  /* 短暂挂上 theme-anim，让配色变化以交叉淡化过渡 */
  root.classList.add('theme-anim');
  root.dataset.theme = theme;
  applyAccent();
  applyPanelAlpha();   /* 面板透明度覆盖按新主题的原始配色重算 */
  clearTimeout(themeAnimTimer);
  themeAnimTimer = setTimeout(() => root.classList.remove('theme-anim'), 340);
}

/* 主题设置对话框：预设卡片 + 强调色取值 */
function renderThemeDlg() {
  if (!themePresets) return;
  themePresets.innerHTML = THEMES.map((t) => `
    <button class="theme-card${state.theme === t.id ? ' is-active' : ''}" data-theme-id="${t.id}">
      <span class="theme-swatch" style="background:${t.swatch[0]}">
        <i style="background:${t.swatch[1]}"></i><i style="background:${t.swatch[2]}"></i>
      </span>
      <b>${t.name}</b>${state.theme === t.id ? '<span class="theme-check">当前</span>' : ''}
    </button>`).join('');
  if (state.accent) { themeAccent.value = state.accent; return; }
  const cur = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim();
  themeAccent.value = rgbToHex(hexToRgb(cur) || { r: 79, g: 214, b: 194 });
}

/* ==================== 背景图片 ==================== */
/* 自定义背景图：存 IndexedDB（图片大，且不挤占 localStorage 里的内容数据）。
   显示为两层固定底图：#bgLayer（图片+模糊，z-index:-2）与 #bgDim（遮暗层，z-index:-1），
   全部应用内容都绘制在其上，任意主题可用；搭配毛玻璃主题最通透。 */
const BG_IDB_KEY = 'bg';
let bgState = { data: '', dim: 25, blur: 0 };
let bgSaveTimer = 0;

function idbBgPut(rec) {
  return idbOpen().then((db) => new Promise((resolve, reject) => {
    const tx = db.transaction('bg', 'readwrite');
    tx.objectStore('bg').put(rec, BG_IDB_KEY);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  }));
}

function idbBgGet() {
  return idbOpen().then((db) => new Promise((resolve, reject) => {
    const rq = db.transaction('bg').objectStore('bg').get(BG_IDB_KEY);
    rq.onsuccess = () => resolve(rq.result || null);
    rq.onerror = () => reject(rq.error);
  }));
}

function idbBgDel() {
  return idbOpen().then((db) => new Promise((resolve, reject) => {
    const tx = db.transaction('bg', 'readwrite');
    tx.objectStore('bg').delete(BG_IDB_KEY);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  }));
}

function ensureBgLayers() {
  if (document.getElementById('bgLayer')) return;
  const layer = document.createElement('div');
  layer.id = 'bgLayer';
  document.body.insertBefore(layer, document.body.firstChild);
  const dim = document.createElement('div');
  dim.id = 'bgDimLayer';   /* 勿与遮暗滑杆 bgDim 重名 */
  document.body.insertBefore(dim, layer.nextSibling);
}

function applyBg(rec) {
  ensureBgLayers();
  bgState = rec && rec.data ? { data: rec.data, dim: rec.dim || 0, blur: rec.blur || 0 } : { data: '', dim: 25, blur: 0 };
  const layer = document.getElementById('bgLayer');
  const dimEl = document.getElementById('bgDimLayer');
  layer.style.backgroundImage = bgState.data ? `url("${bgState.data}")` : '';
  layer.style.filter = bgState.blur ? `blur(${bgState.blur}px)` : '';
  dimEl.style.background = bgState.data ? `rgba(0, 0, 0, ${bgState.dim / 100})` : 'rgba(0,0,0,0)';
}

function updateBgUi(rec) {
  const has = !!(rec && rec.data);
  bgPreview.hidden = !has;
  if (has) bgPreview.src = rec.data;
  bgTuneRow.style.opacity = has ? '1' : '0.45';
  bgDim.disabled = bgBlur.disabled = !has;
  if (has) { bgDim.value = rec.dim || 0; bgBlur.value = rec.blur || 0; }
}

/* 导入并压缩：最长边压到 1920；PNG 结果过大（>1.1MB）时改存 JPEG */
function importBgImage(file) {
  if (!file || !/^image\//.test(file.type)) { showToast('请选择图片文件（JPG / PNG / WebP）'); return; }
  const url = URL.createObjectURL(file);
  const img = new Image();
  img.onload = () => {
    try {
      const MAX = 1920;
      const scale = Math.min(1, MAX / Math.max(img.naturalWidth, img.naturalHeight));
      const w = Math.max(1, Math.round(img.naturalWidth * scale));
      const h = Math.max(1, Math.round(img.naturalHeight * scale));
      const cv = document.createElement('canvas');
      cv.width = w; cv.height = h;
      cv.getContext('2d').drawImage(img, 0, 0, w, h);
      let mime = file.type === 'image/png' ? 'image/png' : 'image/jpeg';
      let data = cv.toDataURL(mime, 0.85);
      if (mime === 'image/png' && data.length > 1500000) data = cv.toDataURL('image/jpeg', 0.85);
      URL.revokeObjectURL(url);
      const rec = { data, dim: bgState.dim, blur: bgState.blur, ts: Date.now() };
      idbBgPut(rec).then(() => {
        applyBg(rec);
        updateBgUi(rec);
        showToast(`背景图片已应用（${w}×${h}，约 ${Math.round(data.length / 1365)}KB）`);
      }).catch(() => showToast('背景图片保存失败：浏览器 IndexedDB 不可用'));
    } catch (e) {
      URL.revokeObjectURL(url);
      showToast('无法处理该图片：' + (e && e.message ? e.message : '未知错误'));
    }
  };
  img.onerror = () => { URL.revokeObjectURL(url); showToast('无法读取该图片文件'); };
  img.src = url;
}

function scheduleBgSave() {
  clearTimeout(bgSaveTimer);
  bgSaveTimer = setTimeout(() => {
    idbBgPut({ data: bgState.data, dim: bgState.dim, blur: bgState.blur, ts: Date.now() }).catch(() => {});
  }, 250);
}

function restoreBg() {
  return idbBgGet().then((rec) => {
    if (rec && rec.data) { applyBg(rec); updateBgUi(rec); }
    else updateBgUi(null);
  }).catch(() => {});
}

/* ==================== 面板透明度 ==================== */
/* 把 --panel / --panel-2 / --panel-3 换算成带 alpha 的 rgba 覆盖在根元素上；
   100 = 移除覆盖（完全跟随主题原生配色），<100 自动挂 panel-glassy 类加毛玻璃模糊 */
function parseColorToRgb(s) {
  s = (s || '').trim();
  let m = /^#([0-9a-f]{6})$/i.exec(s);
  if (m) { const n = parseInt(m[1], 16); return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 }; }
  m = /^#([0-9a-f]{3})$/i.exec(s);
  if (m) { const h = m[1]; return { r: parseInt(h[0] + h[0], 16), g: parseInt(h[1] + h[1], 16), b: parseInt(h[2] + h[2], 16) }; }
  m = /^rgba?\(([^)]+)\)$/i.exec(s);
  if (m) { const p = m[1].split(/[, ]+/).filter(Boolean).map(Number); return { r: p[0], g: p[1], b: p[2] }; }
  return null;
}

function applyPanelAlpha() {
  const root = document.documentElement;
  const a = Math.max(35, Math.min(100, state.panelAlpha || 100));
  if (a >= 100) {
    for (const n of ['--panel', '--panel-2', '--panel-3']) root.style.removeProperty(n);
    root.classList.remove('panel-glassy');
    return;
  }
  const cs = getComputedStyle(root);
  for (const n of ['--panel', '--panel-2', '--panel-3']) {
    const rgb = parseColorToRgb(cs.getPropertyValue(n));
    if (rgb) root.style.setProperty(n, `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${(a / 100).toFixed(2)})`);
  }
  root.classList.add('panel-glassy');
}

function updatePanelAlphaUi() {
  if (!panelAlpha) return;
  panelAlpha.value = String(state.panelAlpha);
  panelAlphaVal.textContent = state.panelAlpha >= 100 ? '默认' : state.panelAlpha + '%';
}

/* ==================== 编辑器字体 ==================== */
/* 内置字体：字体数据内嵌在 fonts-data.js（BUILTIN_FONT_DATA，WOFF2 转 base64），
 * 应用自带字体文件，无需服务器也能加载（file:// 打开同样生效）。
 * 注册进 document.fonts 时不主动解码，首次真正使用才解码。 */
const BUILTIN_FONTS = (typeof BUILTIN_FONT_DATA === 'undefined' ? [] : BUILTIN_FONT_DATA)
  .map((d) => ({ family: d.family, name: d.name, note: d.note }));

function registerBuiltinFonts() {
  if (typeof BUILTIN_FONT_DATA === 'undefined') return;
  for (const d of BUILTIN_FONT_DATA) {
    try {
      /* url(data:) 形式：注册零开销，首次使用时才解码字体 */
      document.fonts.add(new FontFace(d.family, `url(data:font/woff2;base64,${d.b64}) format('woff2')`, { display: 'swap' }));
    } catch { /* 单个字体失败不影响其余 */ }
  }
}

let customFonts = []; // 已导入字体 { id, name, family, face }

/* IndexedDB：持久化导入的字体（localStorage 放不下几 MB 的字体文件） */
function idbOpen() {
  return new Promise((resolve, reject) => {
    /* v2：新增 bg（背景图片）仓；fonts 仓保留（已装字体不丢） */
    const rq = indexedDB.open('lexicode', 2);
    rq.onupgradeneeded = () => {
      const db = rq.result;
      if (!db.objectStoreNames.contains('fonts')) db.createObjectStore('fonts', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('bg')) db.createObjectStore('bg');
    };
    rq.onsuccess = () => resolve(rq.result);
    rq.onerror = () => reject(rq.error);
  });
}

function idbFontPut(rec) {
  return idbOpen().then((db) => new Promise((resolve, reject) => {
    const tx = db.transaction('fonts', 'readwrite');
    tx.objectStore('fonts').put(rec);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  }));
}

function idbFontAll() {
  return idbOpen().then((db) => new Promise((resolve, reject) => {
    const rq = db.transaction('fonts').objectStore('fonts').getAll();
    rq.onsuccess = () => resolve(rq.result || []);
    rq.onerror = () => reject(rq.error);
  }));
}

function idbFontDel(id) {
  return idbOpen().then((db) => new Promise((resolve, reject) => {
    const tx = db.transaction('fonts', 'readwrite');
    tx.objectStore('fonts').delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  }));
}

function registerFontFace(family, data) {
  const face = new FontFace(family, data);
  return face.load().then(() => { document.fonts.add(face); return face; });
}

/* 全局应用字体：选中后界面（--font-ui）与编辑区（--font-editor）都用它；'' = 恢复系统默认 */
function applyFont(family) {
  state.font = family || '';
  const root = document.documentElement;
  if (!family) {
    root.style.removeProperty('--font-ui');
    root.style.removeProperty('--font-editor');
  } else {
    root.style.setProperty('--font-ui', `"${family}", var(--font-ui-base)`);
    root.style.setProperty('--font-editor', `"${family}", var(--font-mono)`);
  }
  positionModeThumb(); /* 字体变化可能改变按钮宽度，重新对齐滑动指示块 */
  readMetrics(); /* 字体变化后同步 measure 元素与行高/内边距，保证补全弹窗定位不漂移 */
}

function renderFontList() {
  if (!fontList) return;
  const isCustom = (family) => customFonts.some((c) => c.family === family);
  const known = (family) => !family || isCustom(family) || BUILTIN_FONTS.some((b) => b.family === family);
  const row = (active, attrs, previewCss, name, note, delId) => `
    <div class="font-item${active ? ' is-active' : ''}" ${attrs}>
      <span class="font-preview" style="font-family:${previewCss}">词条 Aa 123</span>
      <b>${escapeHtml(name)}</b>
      ${note ? `<span class="font-note">${escapeHtml(note)}</span>` : ''}
      ${delId ? `<button class="font-del" data-font-del="${escapeHtml(delId)}" title="删除该字体">✕</button>` : ''}
    </div>`;
  const parts = [
    row(state.font === '', 'data-font-use=""', 'var(--font-ui-base)', '默认', '系统默认', ''),
    ...BUILTIN_FONTS.map((f) => row(
      state.font === f.family, `data-font-use="${f.family}"`, `'${f.family}'`, f.name, f.note, ''
    )),
    ...customFonts.map((c) => row(
      state.font === c.family, `data-font-use="${c.family}"`, `'${c.family}'`, c.name, '已导入', c.id
    )),
  ];
  /* 诊断：内置字体数据缺失时给出可见提示（fonts-data.js 未加载/未随文件分发/浏览器缓存过旧） */
  if (typeof BUILTIN_FONT_DATA === 'undefined') {
    parts.push('<div class="font-item font-missing">未检测到内置字体数据（fonts-data.js）— 请确认文件与 index.html 在同一目录，并按 Ctrl+F5 强制刷新</div>');
  }
  // 选择的字体已不存在（如被其他标签页删除）→ 回退默认
  if (!known(state.font)) applyFont('');
  fontList.innerHTML = parts.join('');
}

function importFontFiles(files) {
  const ok = [...files].filter((f) => /\.(ttf|otf|ttc|woff2?)$/i.test(f.name));
  if (!ok.length) { showToast('未识别的字体文件：支持 TTF / OTF / TTC / WOFF / WOFF2'); return; }
  let pending = ok.length;
  let done = 0;
  ok.forEach((file, i) => {
    const base = file.name.replace(/\.[^.]+$/, '');
    const family = 'lexicode-uf-' + Date.now().toString(36) + '-' + i;
    file.arrayBuffer().then((buf) =>
      registerFontFace(family, buf).then((face) => {
        const rec = { id: family, name: base, family, data: buf };
        customFonts.push({ id: family, name: base, family, face });
        return idbFontPut(rec);
      })
    ).then(() => {
      done++;
      if (done === pending) {
        renderFontList();
        showToast(done === 1 ? `已导入字体「${base}」— 点击列表启用` : `已导入 ${done} 个字体 — 在列表中点击启用`, { duration: 3500 });
      }
    }).catch(() => {
      pending--;
      if (done === pending && pending >= 0) renderFontList();
      showToast(`无法读取字体「${file.name}」— 文件可能已损坏`);
    });
  });
}

/* 启动时注册内置字体、从 IndexedDB 恢复导入的字体，再应用已保存的字体选择 */
function restoreFonts() {
  registerBuiltinFonts();
  return idbFontAll().then((recs) => Promise.all(recs.map((rec) =>
    registerFontFace(rec.family, rec.data).then((face) => {
      customFonts.push({ id: rec.id, name: rec.name, family: rec.family, face });
    }).catch(() => {})
  ))).then(() => {
    const valid = !state.font || BUILTIN_FONTS.some((b) => b.family === state.font)
      || customFonts.some((c) => c.family === state.font);
    applyFont(valid ? state.font : '');
    renderFontList();
  }).catch(() => {});
}

function setMode(mode, silent) {
  state.mode = mode;
  modeToggle.querySelectorAll('.mode-btn').forEach((b) => b.classList.toggle('is-active', b.dataset.mode === mode));
  positionModeThumb();
  if (!silent) {
    scheduleAnalyze(30);
    scheduleSave();
  }
}

/* 把模式切换的滑动指示块对齐到当前激活按钮 */
function positionModeThumb() {
  const active = modeToggle.querySelector('.mode-btn.is-active');
  if (!active) return;
  modeToggle.style.setProperty('--thumb-x', active.offsetLeft + 'px');
  modeToggle.style.setProperty('--thumb-w', active.offsetWidth + 'px');
}

/* ==================== 编辑辅助：包裹 / 注释 ==================== */
function tryExecInsert(text) {
  let ok = false;
  try { ok = document.execCommand('insertText', false, text); } catch { ok = false; }
  return ok;
}

/* 下拉列表：按钮下方弹出（fixed 定位，避免被工具条滚动区裁剪），返回 close 供调用方在动作后收起 */
function wireDrop(btn, menu) {
  const close = () => { menu.hidden = true; menu.style.maxHeight = ''; btn.setAttribute('aria-expanded', 'false'); };
  const open = () => {
    menu.hidden = false;
    /* 先把菜单高度夹进可视区（手机横屏下浏览器工具条会盖住底部），再测量与定位：
       mh ≤ vh-16 保证最坏情况 top=8 时菜单底边 ≤ vh-8，任何矮视口都完整可见 */
    const vh = viewportH(), vw = window.innerWidth;
    menu.style.maxHeight = (vh - 16) + 'px';
    const r = btn.getBoundingClientRect();
    const mw = menu.offsetWidth, mh = menu.offsetHeight;
    const left = Math.max(8, Math.min(r.left, vw - mw - 8));
    let top = r.bottom + 6;
    if (top + mh > vh - 8) { top = r.top - mh - 6; if (top < 8) top = 8; }
    const org = containingBlockOrigin(menu);
    menu.style.left = Math.round(left - org.left) + 'px';
    menu.style.top = Math.round(top - org.top) + 'px';
    btn.setAttribute('aria-expanded', 'true');
  };
  btn.addEventListener('click', (e) => { e.stopPropagation(); menu.hidden ? open() : close(); });
  document.addEventListener('pointerdown', (e) => {
    if (!menu.hidden && !menu.contains(e.target) && !btn.contains(e.target)) close();
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !menu.hidden) close(); });
  window.addEventListener('resize', close);
  if (window.visualViewport) window.visualViewport.addEventListener('resize', close); /* 旋转屏幕 / 软键盘弹出时收起 */
  /* 页面滚动时收起；但菜单自身滚动（e.target 在菜单内）不收起，否则列表无法滚动 */
  window.addEventListener('scroll', (e) => {
    if (menu.hidden || menu.contains(e.target)) return;
    close();
  }, true);
  return close;
}

/* ==================== 右击行诊断菜单 ====================
 * 字符级坐标可能错位，因此按行定位：clientY → 行号（固定行高数学），
 * 列出该行全部诊断；无诊断的行不拦截，保留浏览器原生菜单。 */
let errMenuProblems = [];

function closeErrMenu() {
  errMenu.hidden = true;
  errMenu.style.maxHeight = '';
  errMenuProblems = [];
}

function wireErrMenu() {
  codeInput.addEventListener('contextmenu', (e) => {
    const rect = codeInput.getBoundingClientRect();
    const lineIdx = Math.floor((e.clientY - rect.top + codeInput.scrollTop - PAD_TOP) / LINE_H);
    const pl = state.parsedLines[lineIdx];
    const probs = pl ? pl.problems : [];
    if (!probs.length) return;
    e.preventDefault();
    errMenuProblems = probs.slice().sort((a, b) => a.start - b.start);
    errMenu.innerHTML =
      `<div class="drop-group">第 ${lineIdx + 1} 行 · ${errMenuProblems.length} 项诊断</div>` +
      errMenuProblems.map((p, i) => {
        const sev = p.severity === 'error' ? 'sev-err' : 'sev-warn';
        return `<button class="drop-item err-item ${sev}" data-i="${i}" title="点击跳转">
          <span class="sev-tag">${p.severity === 'error' ? '错误' : '警告'}</span>
          <span class="err-item-msg">${escapeHtml(p.message)}</span>
          <span class="err-item-code">${escapeHtml(p.code)}</span>
        </button>`;
      }).join('');
    errMenu.hidden = false;
    /* 光标处弹出，可视区内夹紧（先渲染再测量尺寸；高度先夹进可视区，防手机横屏被浏览器工具条挡住） */
    errMenu.style.maxHeight = (viewportH() - 16) + 'px';
    const mw = errMenu.offsetWidth, mh = errMenu.offsetHeight;
    const left = Math.max(8, Math.min(e.clientX + 4, window.innerWidth - mw - 8));
    let top = e.clientY + 6;
    if (top + mh > viewportH() - 8) { top = e.clientY - mh - 6; if (top < 8) top = 8; }
    const org = containingBlockOrigin(errMenu);
    errMenu.style.left = Math.round(left - org.left) + 'px';
    errMenu.style.top = Math.round(top - org.top) + 'px';
  });

  /* 点击诊断项 → 关菜单并精确跳转 */
  errMenu.addEventListener('click', (e) => {
    const item = e.target.closest('.err-item');
    if (!item) return;
    const p = errMenuProblems[Number(item.dataset.i)];
    closeErrMenu();
    if (p) jumpTo(p);
  });

  document.addEventListener('pointerdown', (e) => {
    if (!errMenu.hidden && !errMenu.contains(e.target)) closeErrMenu();
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !errMenu.hidden) closeErrMenu(); });
  window.addEventListener('resize', closeErrMenu);
  /* 编辑器滚动时收起（capture 捕获 textarea 滚动）；菜单自身滚动不收起 */
  window.addEventListener('scroll', (e) => {
    if (errMenu.hidden || errMenu.contains(e.target)) return;
    closeErrMenu();
  }, true);
}

function wrapSelection(open, close) {
  const s = codeInput.selectionStart;
  const e = codeInput.selectionEnd;
  const sel = codeInput.value.slice(s, e);
  codeInput.focus();
  if (sel) {
    codeInput.setSelectionRange(s, e);
    if (!tryExecInsert(open + sel + close)) return;
    codeInput.setSelectionRange(s + open.length, s + open.length + sel.length);
  } else {
    if (!tryExecInsert(open + close)) return;
    codeInput.setSelectionRange(s + open.length, s + open.length);
  }
  scheduleAnalyze(30);
  scheduleSave();
}

function toggleComment() {
  const v = codeInput.value;
  let s = codeInput.selectionStart;
  let e = codeInput.selectionEnd;
  const lineStart = v.lastIndexOf('\n', Math.max(0, s - 1)) + 1;
  let lineEnd = v.indexOf('\n', e);
  if (lineEnd === -1) lineEnd = v.length;
  const lines = v.slice(lineStart, lineEnd).split('\n');
  const allCommented = lines.every((l) => l.trim() === '' || l.trim().startsWith('//'));
  const next = lines.map((l) => {
    if (l.trim() === '') return l;
    if (allCommented) {
      const i = l.indexOf('//');
      let out = l.slice(0, i) + l.slice(i + 2);
      if (out[i] === ' ') out = out.slice(0, i) + out.slice(i + 1);
      return out;
    }
    return '// ' + l;
  }).join('\n');
  if (next === v.slice(lineStart, lineEnd)) return;
  codeInput.focus();
  codeInput.setSelectionRange(lineStart, lineEnd);
  if (!tryExecInsert(next)) {
    codeInput.value = v.slice(0, lineStart) + next + v.slice(lineEnd);
    codeInput.setSelectionRange(lineStart, lineStart + next.length);
    codeInput.dispatchEvent(new Event('input', { bubbles: true }));
  }
  codeInput.setSelectionRange(lineStart, lineStart + next.length);
  scheduleAnalyze(30);
  scheduleSave();
}

/* ==================== 词条编辑器（可视化构建） ==================== */
const builder = {
  items: [],        // {type:'term', term, optional} | {type:'choice', options:[]}
  selected: -1,     // 当前选中行（选项组行时，词库点击加入该组）
};

function builderText() {
  const parts = [];
  let prevPlain = false;
  for (const it of builder.items) {
    if (it.type === 'term') {
      const t = it.optional ? `[${it.term}]` : it.term;
      parts.push((prevPlain && !it.optional ? ' ' : '') + t);
      prevPlain = !it.optional;
    } else {
      if (!it.options.length) continue;
      parts.push((prevPlain ? ' ' : '') + '{' + it.options.join('|') + '}');
      prevPlain = false;
    }
  }
  return parts.join('');
}

/* ==================== 智能拆词 ==================== */
const SPLIT_MAX = 500;

function openSplit() {
  splitInput.value = '';
  splitList.innerHTML = '';
  splitCount.textContent = `0 / ${SPLIT_MAX}`;
  splitCount.classList.remove('over');
  splitRun.disabled = true;
  /* 编辑器里有选中内容且不超过上限时，自动带入并拆分 */
  const sel = codeInput.value.slice(codeInput.selectionStart, codeInput.selectionEnd).trim();
  if (sel && sel.length <= SPLIT_MAX) splitInput.value = sel;
  updateSplitCount();
  if (splitInput.value) runSmartSplit();
  dlgSplit.showModal();
  splitInput.focus();
}

function updateSplitCount() {
  const n = splitInput.value.length;
  splitCount.textContent = `${n} / ${SPLIT_MAX}`;
  splitCount.classList.toggle('over', n > SPLIT_MAX);
  splitRun.disabled = !n || n > SPLIT_MAX;
}

/* 拆词引擎：输入一段语句，返回候选词条 [{ term, count }]。
   1) 按空白 / 数字 / 标点 / 语法字符切段；
   2) 已知片段交给 segmentRun 切分，未收录字符汇入待拆池；
   3) 待拆池统计 2–4 字组合，频次 ≥ 2 才成为候选；
   4) 子串去重（短候选被更长候选包含且后者频次不降时丢弃短者）；
   5) 排除词库已有词条，按频次 / 长度排序。 */
function smartSplit(text) {
  const chunks = [];
  let buf = '';
  const flush = () => { if (buf) { chunks.push(buf); buf = ''; } };
  for (const ch of text) {
    if (/[\s\d\p{P}\p{S}]/u.test(ch)) flush();
    else buf += ch;
  }
  flush();

  const unknowns = [];
  for (const chunk of chunks) {
    const segs = segmentRun(chunk);
    let unk = '';
    for (const seg of segs) {
      if (seg.word) {
        if (unk) { unknowns.push(unk); unk = ''; }
        continue;
      }
      unk += chunk.slice(seg.start, seg.start + seg.len);
    }
    if (unk) unknowns.push(unk);
  }

  const grams = new Map();
  for (const region of unknowns) {
    for (let L = 2; L <= 4; L++) {
      for (let i = 0; i + L <= region.length; i++) {
        const g = region.slice(i, i + L);
        grams.set(g, (grams.get(g) || 0) + 1);
      }
    }
  }
  let cands = [...grams.entries()].filter(([, c]) => c >= 2).map(([term, count]) => ({ term, count }));

  const dropped = new Set();
  for (const a of cands) {
    for (const b of cands) {
      if (a !== b && b.term.includes(a.term) && b.count >= a.count) { dropped.add(a.term); break; }
    }
  }
  return cands
    .filter((c) => !dropped.has(c.term) && !state.lexicon.has(c.term))
    .sort((a, b) => b.count - a.count || b.term.length - a.term.length || a.term.localeCompare(b.term, 'zh-Hans-CN'));
}

function runSmartSplit() {
  splitList.innerHTML = '';
  if (splitRun.disabled) return;
  const cands = smartSplit(splitInput.value);
  if (!cands.length) {
    splitList.innerHTML = '<div class="split-empty">没有提取到候选词条。<br>只在文中重复出现 2 次以上的未知片段才会被提取，词库已有的词条不会重复列出。</div>';
    return;
  }
  splitList.innerHTML = cands.map((c) =>
    `<label class="split-item" title="“${escapeHtml(c.term)}”在文中出现 ${c.count} 次">
      <input type="checkbox" checked data-term="${escapeHtml(c.term)}">
      <span class="lex-word">${escapeHtml(c.term)}</span>
      <span class="split-count">出现 ${c.count} 次</span>
    </label>`).join('');
}

function splitApplySelected() {
  const boxes = [...splitList.querySelectorAll('input[type="checkbox"]:checked')];
  if (!boxes.length) { showToast('请先勾选要加入词库的词条'); return; }
  let added = 0, skipped = 0;
  for (const b of boxes) {
    const r = addTerm(b.dataset.term);
    if (r.ok) added++; else skipped++;
  }
  dlgSplit.close();
  showToast(added ? `已添加 ${added} 个词条${skipped ? `，跳过 ${skipped} 个（已存在）` : ''}` : '没有新增词条（均已在词库中）');
}

function openBuilder() {
  const sel = codeInput.value.slice(codeInput.selectionStart, codeInput.selectionEnd);
  builder.items = [];
  builder.selected = -1;
  const s = sel.trim();
  if (s && !s.includes('\n')) {
    if (lexSet.has(s)) builder.items.push({ type: 'term', term: s, optional: false });
    else if (s.includes('[') || s.includes('{')) {
      /* 尝试按现有语法解析进构建器（简化：整行作为可省略项结构还原） */
      builder.items = parseBuilderText(s);
    } else if (/^[\u4e00-\u9fa5a-zA-Z0-9]+$/.test(s)) {
      builder.items.push({ type: 'term', term: s, optional: false });
    }
  }
  builderSearch.value = '';
  dlgBuilder.showModal();
  renderBuilder();
}

/* 将一行已有语法粗略还原为结构（支持嵌套一层） */
function parseBuilderText(text) {
  const items = [];
  let i = 0;
  let buf = '';
  const flush = () => {
    if (buf) { items.push({ type: 'term', term: buf, optional: false }); buf = ''; }
  };
  while (i < text.length) {
    const ch = text[i];
    if (ch === '[') {
      flush();
      const close = text.indexOf(']', i);
      if (close === -1) { buf += ch; i++; continue; }
      const inner = text.slice(i + 1, close).trim();
      if (inner.includes('{')) items.push({ type: 'choice', options: inner.replace(/[{}]/g, '').split('|').map((x) => x.trim()).filter(Boolean) });
      else if (inner) items.push({ type: 'term', term: inner, optional: true });
      i = close + 1;
      continue;
    }
    if (ch === '{') {
      flush();
      const close = text.indexOf('}', i);
      if (close === -1) { buf += ch; i++; continue; }
      const opts = text.slice(i + 1, close).split('|').map((x) => x.trim()).filter(Boolean);
      if (opts.length) items.push({ type: 'choice', options: opts });
      i = close + 1;
      continue;
    }
    if (isSepChar(ch)) { flush(); i++; continue; }
    if (isSymChar(ch)) { flush(); i++; continue; } /* 符号（，。（）【】“”等）不进入构建器结构 */
    buf += ch;
    i++;
  }
  flush();
  return items;
}

function renderBuilder() {
  /* 词库选择列表 */
  const q = builderSearch.value.trim().toLowerCase();
  let html = '';
  let shown = 0;
  for (const term of state.terms) {
    const note = state.lexicon.get(term) || '';
    if (q && !term.toLowerCase().includes(q) && !note.toLowerCase().includes(q)) continue;
    if (shown >= 80) break;
    if (term.includes('……')) continue; /* 通配词条不进词条编辑器（构建的是正文内容） */
    shown++;
    html += `<li class="lex-item" data-term="${escapeHtml(term)}" tabindex="0"><span class="lex-word">${escapeHtml(term)}</span></li>`;
  }
  builderTerms.innerHTML = html || '<li class="lex-empty">没有匹配的词条</li>';
  builderTargetHint.textContent = builder.selected >= 0 && builder.items[builder.selected] && builder.items[builder.selected].type === 'choice'
    ? `点击词条：添加到「选项组 ${builder.selected + 1}」`
    : '点击词条：添加到「末尾」';

  /* 结构列表 */
  if (!builder.items.length) {
    builderItems.innerHTML = '<div class="b-empty">还没有内容：从左侧词库点击添加，或新建选项组</div>';
  } else {
    builderItems.innerHTML = builder.items.map((it, idx) => {
      const selectedCls = idx === builder.selected ? ' is-selected' : '';
      const upDown = `<button class="b-icon-btn" data-do="up" data-idx="${idx}" title="上移">↑</button>
        <button class="b-icon-btn" data-do="down" data-idx="${idx}" title="下移">↓</button>`;
      if (it.type === 'term') {
        return `<div class="b-item${selectedCls}" data-idx="${idx}">
          <span class="b-term">${escapeHtml(it.term)}</span>
          ${it.optional ? '<span class="b-opt-tag">可省略 [ ]</span>' : ''}
          <label title="设为可省略值 [ ]"><input type="checkbox" data-do="opt" data-idx="${idx}" ${it.optional ? 'checked' : ''}>可省略</label>
          <span style="flex:1"></span>
          ${upDown}
          <button class="b-icon-btn danger" data-do="del" data-idx="${idx}" title="删除">×</button>
        </div>`;
      }
      const chips = it.options.map((o, oi) =>
        `<span class="b-opt-chip">${escapeHtml(o)}<button data-do="delopt" data-idx="${idx}" data-oi="${oi}" title="移除该选项">×</button></span>`
      ).join('');
      return `<div class="b-item b-choice${selectedCls}" data-idx="${idx}">
        <span class="b-opt-tag">选项组 { }</span>
        <span class="b-choice-list">${chips || '<span class="b-empty" style="padding:0">暂无选项</span>'}</span>
        <span style="flex:1"></span>
        ${upDown}
        <button class="b-icon-btn danger" data-do="del" data-idx="${idx}" title="删除">×</button>
      </div>`;
    }).join('');
  }

  /* 预览与校验 */
  const text = builderText();
  builderPreview.innerHTML = text
    ? escapeHtml(text)
        .replace(/[\[\]{}]/g, '<span class="bp-bracket">$&</span>')
        .replace(/\|/g, '<span class="bp-pipe">|</span>')
    : '<span style="color:var(--text-faint)">（空）</span>';

  if (!text) {
    builderDiag.className = '';
    builderDiag.textContent = '构建完成后自动校验';
    builderInsert.disabled = true;
    return;
  }
  const pl = parseLine(text, 0, 0);
  if (!pl.problems.length) {
    builderDiag.className = '';
    builderDiag.textContent = '✓ 校验通过：所有片段都已收录';
    builderInsert.disabled = false;
  } else {
    const p = pl.problems[0];
    builderDiag.className = 'bad';
    const chips = (p.suggestions && p.suggestions.length)
      ? ` <button class="sugg-chip" data-fix="${escapeHtml(p.suggestions[0])}" data-idx="${builderItemIndexFor(p.start)}">改为「${escapeHtml(p.suggestions[0])}」</button>` : '';
    builderDiag.innerHTML = `⚠ ${escapeHtml(p.message)}${chips}`;
    builderInsert.disabled = false;
  }
}

function builderItemIndexFor(offset) {
  /* 与 builderText 完全一致的拼装方式，找到偏移所在的项 */
  let acc = 0;
  let prevPlain = false;
  for (let idx = 0; idx < builder.items.length; idx++) {
    const it = builder.items[idx];
    let t, isPlain;
    if (it.type === 'term') {
      t = it.optional ? `[${it.term}]` : it.term;
      isPlain = !it.optional;
    } else {
      if (!it.options.length) continue;
      t = '{' + it.options.join('|') + '}';
      isPlain = false;
    }
    const space = prevPlain && isPlain ? 1 : 0;
    const start = acc + space;
    if (offset >= start && offset <= start + t.length) return idx;
    acc = start + t.length;
    prevPlain = isPlain;
  }
  return -1;
}

function builderFixTerm(idx, term) {
  const it = builder.items[idx];
  if (!it) return;
  if (it.type === 'term') it.term = term;
  else it.options = [term];
  renderBuilder();
}

function builderInsertToEditor() {
  const text = builderText();
  if (!text) return;
  dlgBuilder.close();
  codeInput.focus();
  const pos = codeInput.selectionStart;
  codeInput.setSelectionRange(pos, codeInput.selectionEnd);
  if (!tryExecInsert(text)) {
    const v = codeInput.value;
    codeInput.value = v.slice(0, pos) + text + v.slice(pos);
    codeInput.setSelectionRange(pos + text.length, pos + text.length);
    codeInput.dispatchEvent(new Event('input', { bubbles: true }));
  }
  scheduleAnalyze(30);
  scheduleSave();
  showToast(`已插入词条：${text}`);
}

function bindBuilderEvents() {
  builderSearch.addEventListener('input', renderBuilder);
  builderTerms.addEventListener('click', (e) => {
    const item = e.target.closest('.lex-item');
    if (!item) return;
    const term = item.dataset.term;
    const sel = builder.selected >= 0 ? builder.items[builder.selected] : null;
    if (sel && sel.type === 'choice') sel.options.push(term);
    else {
      builder.items.push({ type: 'term', term, optional: false });
      builder.selected = builder.items.length - 1;
    }
    renderBuilder();
  });

  builderItems.addEventListener('click', (e) => {
    /* “可省略”复选框交给 change 事件，避免重渲染吞掉事件 */
    if (e.target.closest('label')) return;
    const doBtn = e.target.closest('[data-do]');
    const row = e.target.closest('.b-item');
    const idx = row ? +row.dataset.idx : -1;
    if (idx >= 0) builder.selected = idx;

    if (!doBtn) { renderBuilder(); return; }
    const act = doBtn.dataset.do;
    const it = builder.items[idx];
    if (act === 'opt') { /* checkbox 由 change 事件处理 */ return; }
    if (act === 'up' && idx > 0) { [builder.items[idx - 1], builder.items[idx]] = [builder.items[idx], builder.items[idx - 1]]; builder.selected = idx - 1; }
    else if (act === 'down' && idx < builder.items.length - 1) { [builder.items[idx + 1], builder.items[idx]] = [builder.items[idx], builder.items[idx + 1]]; builder.selected = idx + 1; }
    else if (act === 'del') { builder.items.splice(idx, 1); builder.selected = -1; }
    else if (act === 'delopt') { it.options.splice(+doBtn.dataset.oi, 1); if (!it.options.length) builder.items.splice(idx, 1); }
    renderBuilder();
  });

  builderItems.addEventListener('change', (e) => {
    const cb = e.target.closest('input[data-do="opt"]');
    if (!cb) return;
    const it = builder.items[+cb.dataset.idx];
    if (it && it.type === 'term') it.optional = cb.checked;
    renderBuilder();
  });

  builderItems.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const row = e.target.closest('.b-item');
      if (row) { e.preventDefault(); builder.selected = +row.dataset.idx; renderBuilder(); }
    }
  });

  builderAddChoice.addEventListener('click', () => {
    builder.items.push({ type: 'choice', options: [] });
    builder.selected = builder.items.length - 1;
    renderBuilder();
    builderSearch.focus();
  });
  builderClear.addEventListener('click', () => { builder.items = []; builder.selected = -1; renderBuilder(); });
  builderInsert.addEventListener('click', builderInsertToEditor);
  builderCancel.addEventListener('click', () => dlgBuilder.close());
  builderClose.addEventListener('click', () => dlgBuilder.close());

  /* 智能拆词 */
  splitInput.addEventListener('input', updateSplitCount);
  splitRun.addEventListener('click', runSmartSplit);
  splitAdd.addEventListener('click', splitApplySelected);
  splitSelectAll.addEventListener('click', () => {
    const boxes = [...splitList.querySelectorAll('input[type="checkbox"]')];
    if (!boxes.length) return;
    const all = boxes.every((b) => b.checked);
    for (const b of boxes) b.checked = !all;
  });
  splitClose.addEventListener('click', () => dlgSplit.close());
  splitCancel.addEventListener('click', () => dlgSplit.close());

  /* 历史快照 */
  btnSnaps.addEventListener('click', () => { renderSnaps(); dlgSnaps.showModal(); });
  snapClose.addEventListener('click', () => dlgSnaps.close());
  snapCancel.addEventListener('click', () => dlgSnaps.close());
  snapList.addEventListener('click', (e) => {
    const item = e.target.closest('.snap-item');
    if (item) restoreSnapshot(+item.dataset.snapI);
  });
  /* 切走页面 / 关闭标签前立即落盘，防抖存的版本不丢 */
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') { clearTimeout(saveTimer); save(); }
  });

  builderDiag.addEventListener('click', (e) => {
    const chip = e.target.closest('.sugg-chip');
    if (chip) builderFixTerm(+chip.dataset.idx, chip.dataset.fix);
  });
}

/* ==================== 输入规范化 ==================== */
function normalizeNewlines() {
  const v = codeInput.value;
  if (!v.includes('\r')) return;
  const pos = codeInput.selectionStart;
  const adjusted = v.slice(0, pos).replace(/\r\n?/g, '\n').length;
  codeInput.value = v.replace(/\r\n?/g, '\n');
  codeInput.setSelectionRange(adjusted, adjusted);
}

/* ==================== 编辑器字号 ==================== */
/* 字号加减：只改 --ed-fs / --ed-lh 两个变量，高亮层与输入层同步缩放；
   行高按 24/14 比例联动，readMetrics 同步 measure 元素（补全弹窗定位不漂移） */
function applyEditorSize(size, silent) {
  size = Math.max(10, Math.min(28, Math.round(size)));
  state.edSize = size;
  const lh = Math.round((size * 12) / 7); /* 14px → 24px */
  const root = document.documentElement;
  root.style.setProperty('--ed-fs', size + 'px');
  root.style.setProperty('--ed-lh', lh + 'px');
  readMetrics();
  const lbl = document.getElementById('edSizeLabel');
  if (lbl) lbl.textContent = size + 'px';
  if (!silent) {
    showToast(`编辑器字号 ${size}px`);
    scheduleSave();
  }
}

/* ==================== 事件绑定 ==================== */
function readMetrics() {
  const cs = getComputedStyle(codeInput);
  PAD_TOP = parseFloat(cs.paddingTop) || 12;
  PAD_LEFT = parseFloat(cs.paddingLeft) || 18;
  LINE_H = parseFloat(cs.lineHeight) || 24;
  measure.style.fontSize = cs.fontSize;
  measure.style.fontFamily = cs.fontFamily;
  measure.style.fontWeight = cs.fontWeight;
  measure.style.letterSpacing = cs.letterSpacing;
}

function bindEvents() {
  /* 编辑器 */
  codeInput.addEventListener('input', () => {
    normalizeNewlines();
    scheduleAnalyze();
    scheduleSave();
    updateCaretInfo();
    updateActiveLine();
    scheduleAc();
  });
  codeInput.addEventListener('scroll', syncScroll);
  setupEditorDrag(codeInput);   /* 拖放移动：可见幽灵图 + 落点按行吸附 */
  codeInput.addEventListener('blur', () => { setTimeout(closeAc, 120); clearTimeout(saveTimer); save(); /* 失焦立即落盘 */ });

  document.addEventListener('selectionchange', () => {
    if (document.activeElement !== codeInput || composing) return;
    /* 点击 / 方向键 / Home·End 移动光标时：活动行高亮与状态栏行列立即跟随（修复锁定区域与实际位置不同） */
    updateActiveLine();
    updateCaretInfo();
    scheduleAc(30);
  });
  codeInput.addEventListener('compositionstart', () => { composing = true; closeAc(); });
  codeInput.addEventListener('compositionend', () => { composing = false; scheduleAnalyze(); scheduleAc(120); });

  /* 补全面板点击 */
  acList.addEventListener('mousedown', (e) => {
    e.preventDefault();
    const item = e.target.closest('.ac-item');
    if (item) acceptAc(acState.items[+item.dataset.idx].term);
  });

  /* 行号 */
  gutterEl.addEventListener('click', (e) => {
    const line = e.target.closest('.gutter-line');
    if (!line) return;
    const idx = +line.dataset.line;
    const text = codeInput.value;
    let start = 0;
    for (let i = 0; i < idx; i++) {
      const nl = text.indexOf('\n', start);
      if (nl === -1) break;
      start = nl + 1;
    }
    let end = text.indexOf('\n', start);
    if (end === -1) end = text.length;
    applySelection(start, end);
  });

  /* 诊断列表 */
  diagList.addEventListener('click', (e) => {
    const chip = e.target.closest('.sugg-chip');
    if (chip) {
      const s = +chip.dataset.start, t = chip.dataset.term;
      codeInput.focus();
      codeInput.setSelectionRange(s, s);
      codeInput.setSelectionRange(s, +chip.dataset.end);
      try { document.execCommand('insertText', false, t); } catch { /* 忽略 */ }
      scheduleAnalyze(30);
      return;
    }
    const item = e.target.closest('.diag-item');
    if (!item) return;
    jumpTo({ start: +item.dataset.start, end: +item.dataset.end });
  });

  diagFilter.addEventListener('click', (e) => {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    state.filter = chip.dataset.f;
    diagFilter.querySelectorAll('.chip').forEach((c) => c.classList.toggle('is-active', c === chip));
    renderDiagnostics();
  });

  /* 校验模式 */
  modeToggle.addEventListener('click', (e) => {
    const btn = e.target.closest('.mode-btn');
    if (btn) setMode(btn.dataset.mode);
  });

  /* 词库 */
  lexList.addEventListener('click', (e) => {
    const del = e.target.closest('.lex-del');
    if (del) {
      const item = del.closest('.lex-item');
      if (item) deleteTerm(item.dataset.term);
      return;
    }
    const item = e.target.closest('.lex-item');
    if (item) insertTermIntoEditor(item.dataset.term);
  });
  lexList.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const item = e.target.closest('.lex-item');
      if (item) { e.preventDefault(); insertTermIntoEditor(item.dataset.term); }
    }
  });
  lexSearch.addEventListener('input', renderLexicon);

  const doAdd = () => {
    const res = addTerm(lexAddInput.value);
    showToast(res.msg, { duration: res.ok ? 2200 : 3500 });
    if (res.ok) lexAddInput.value = '';
    lexAddInput.focus();
  };
  lexAddBtn.addEventListener('click', doAdd);
  lexAddInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') doAdd(); });

  /* 导入导出 */
  btnImportLex.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', () => {
    if (fileInput.files && fileInput.files[0]) handleImport(fileInput.files[0]);
    fileInput.value = '';
  });
  btnExportLex.addEventListener('click', exportLexicon);

  /* 拖放导入 */
  panelLexicon.addEventListener('dragover', (e) => {
    e.preventDefault();
    panelLexicon.classList.add('dragging');
  });
  panelLexicon.addEventListener('dragleave', () => panelLexicon.classList.remove('dragging'));
  panelLexicon.addEventListener('drop', (e) => {
    e.preventDefault();
    panelLexicon.classList.remove('dragging');
    const f = e.dataTransfer.files && e.dataTransfer.files[0];
    if (f) handleImport(f);
  });

  /* 顶栏 */
  btnThemeCfg.addEventListener('click', () => { renderThemeDlg(); renderFontList(); dlgTheme.showModal(); });
  themeClose.addEventListener('click', () => dlgTheme.close());

  /* 项目下拉：打开时重渲染（保证名称最新），再交给 wireDrop 开合 */
  btnProjects.addEventListener('click', () => { if (projMenu.hidden) renderProjMenu(); });
  const closeProjMenu = wireDrop(btnProjects, projMenu);
  projMenu.addEventListener('click', (e) => {
    const item = e.target.closest('.drop-item');
    if (!item) return;
    closeProjMenu();
    if (item.dataset.proj) switchProject(item.dataset.proj);
    else if (item.dataset.projAct === 'new') newProject();
    else if (item.dataset.projAct === 'rename') openProjRename();
    else if (item.dataset.projAct === 'del') deleteProject();
  });
  projNameOk.addEventListener('click', confirmProjRename);
  projNameClose.addEventListener('click', () => dlgProjName.close());
  projNameInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') confirmProjRename(); });

  /* 背景图片（主题设置内） */
  btnBgImport.addEventListener('click', () => bgFileInput.click());
  bgFileInput.addEventListener('change', () => {
    if (bgFileInput.files && bgFileInput.files[0]) importBgImage(bgFileInput.files[0]);
    bgFileInput.value = '';
  });
  btnBgClear.addEventListener('click', () => {
    idbBgDel().catch(() => {});
    applyBg(null);
    updateBgUi(null);
    showToast('已清除背景图片');
  });
  btnBgGlass.addEventListener('click', () => {
    applyTheme('glass');
    renderThemeDlg();
    scheduleSave();
    showToast('已切换到毛玻璃主题');
  });
  const tuneBg = () => {
    if (!bgState.data) return;
    const rec = { data: bgState.data, dim: +bgDim.value, blur: +bgBlur.value, ts: Date.now() };
    applyBg(rec);
    scheduleBgSave();
  };
  bgDim.addEventListener('input', tuneBg);
  bgBlur.addEventListener('input', tuneBg);

  /* 面板透明度：拖动实时预览，松手落盘 */
  panelAlpha.addEventListener('input', () => {
    state.panelAlpha = +panelAlpha.value;
    panelAlphaVal.textContent = state.panelAlpha >= 100 ? '默认' : state.panelAlpha + '%';
    applyPanelAlpha();
  });
  panelAlpha.addEventListener('change', persistPrefs);
  themePresets.addEventListener('click', (e) => {
    const card = e.target.closest('[data-theme-id]');
    if (!card || card.dataset.themeId === state.theme) return;
    applyTheme(card.dataset.themeId);
    renderThemeDlg();
    scheduleSave();
    showToast(`已切换主题：${themeMeta(card.dataset.themeId).name}`);
  });
  themeAccent.addEventListener('input', () => {
    const v = /^#[0-9a-f]{6}$/i.test(themeAccent.value) ? themeAccent.value.toLowerCase() : '';
    state.accent = v;
    applyAccent();
    renderThemeDlg();
    scheduleSave();
  });
  themeAccentReset.addEventListener('click', () => {
    state.accent = '';
    applyAccent();
    themeAccent.value = rgbToHex(hexToRgb(getComputedStyle(document.documentElement).getPropertyValue('--accent')) || { r: 79, g: 214, b: 194 });
    renderThemeDlg();
    scheduleSave();
    showToast('已恢复默认强调色');
  });

  /* 编辑器字体 */
  btnFontImport.addEventListener('click', () => fontFileInput.click());
  document.getElementById('btnEdSizeMinus').addEventListener('click', () => applyEditorSize(state.edSize - 1));
  document.getElementById('btnEdSizePlus').addEventListener('click', () => applyEditorSize(state.edSize + 1));
  document.getElementById('btnEdSizeReset').addEventListener('click', () => applyEditorSize(14));
  fontFileInput.addEventListener('change', () => {
    importFontFiles(fontFileInput.files);
    fontFileInput.value = '';
  });
  fontList.addEventListener('click', (e) => {
    const del = e.target.closest('[data-font-del]');
    if (del) {
      const id = del.dataset.fontDel;
      const rec = customFonts.find((c) => c.id === id);
      if (!rec) return;
      idbFontDel(id).catch(() => {});
      document.fonts.delete(rec.face);
      customFonts = customFonts.filter((c) => c.id !== id);
      if (state.font === rec.family) { applyFont(''); scheduleSave(); }
      renderFontList();
      showToast(`已删除字体「${rec.name}」`);
      return;
    }
    const use = e.target.closest('[data-font-use]');
    if (use && use.dataset.fontUse !== state.font) {
      applyFont(use.dataset.fontUse);
      scheduleSave();
      renderFontList();
    }
  });
  btnHelp.addEventListener('click', () => dlgHelp.showModal());
  document.getElementById('helpClose').addEventListener('click', () => dlgHelp.close());
  btnRules.addEventListener('click', () => { renderRulesToggles(); dlgRules.showModal(); });
  rulesClose.addEventListener('click', () => dlgRules.close());
  dlgConfirm.addEventListener('click', (e) => {
    const btn = e.target.closest('button[value]');
    if (!btn) return;
    dlgConfirm.close(btn.value === 'ok' ? 'ok' : 'cancel');
  });
  rulesToggles.addEventListener('change', (e) => {
    const cb = e.target.closest('input[data-rule]');
    if (!cb) return;
    rules[cb.dataset.rule] = cb.checked;
    saveRules();
    scheduleAnalyze(20);
    showToast(cb.checked ? '规则已启用' : '规则已关闭（不再标红与提示）');
  });
  btnKeys.addEventListener('click', () => { cancelCapture(); renderKeys(); dlgKeys.showModal(); });
  keysClose.addEventListener('click', () => dlgKeys.close());
  keysDone.addEventListener('click', () => dlgKeys.close());
  keysReset.addEventListener('click', () => {
    for (const a of KEY_ACTIONS) bindings[a.id] = a.def;
    saveBindings();
    cancelCapture();
    renderHelpKeys();
    keysHint.textContent = '已恢复默认快捷键';
    keysHint.classList.remove('conflict');
  });
  keysList.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-act]');
    if (!btn) return;
    const id = btn.dataset.act;
    if (btn.dataset.mode === 'cancel') cancelCapture();
    else startCapture(id);
  });
  btnHelpKeys.addEventListener('click', () => {
    dlgHelp.close();
    cancelCapture();
    renderKeys();
    dlgKeys.showModal();
  });
  btnSample.addEventListener('click', async () => {
    const ok = await openConfirm({
      title: '载入示例',
      body: '载入示例会覆盖当前的词库与编辑内容，是否继续？',
      okText: '载入示例',
      danger: false,
    });
    if (ok) {
      loadDemo();
      rebuildIndex();
      renderLexicon();
      scheduleAnalyze(20);
      scheduleSave();
      showToast('已载入示例词库与内容');
    }
  });

  /* 响应式面板开关 */
  btnToggleLex.addEventListener('click', () => {
    panelLexicon.classList.toggle('is-open');
    panelDiag.classList.remove('is-open');
  });
  btnToggleDiag.addEventListener('click', () => {
    panelDiag.classList.toggle('is-open');
    panelLexicon.classList.remove('is-open');
  });

  /* 编辑辅助工具条 */
  ebBuilder.addEventListener('click', openBuilder);
  ebSplit.addEventListener('click', openSplit);

  /* 编辑区右击 → 该行诊断菜单 */
  wireErrMenu();

  /* 符号与语法列表：包裹选中内容 / 插入符号 / 注释 */
  renderSymMenu();
  const closeSymMenu = wireDrop(ebSymBtn, symMenu);
  symMenu.addEventListener('click', (e) => {
    const item = e.target.closest('[data-act]');
    if (!item) return;
    closeSymMenu();
    if (item.dataset.act === 'wrap') { wrapSelection(item.dataset.open, item.dataset.close); return; }
    if (item.dataset.act === 'comment') { toggleComment(); return; }
    codeInput.focus();
    if (!tryExecInsert(item.dataset.ins)) return;
    scheduleAnalyze(30);
    scheduleSave();
  });

  /* 导出列表：编辑内容 / 词库 / 校验报告 */
  const closeExportMenu = wireDrop(btnExportBtn, exportMenu);
  exportMenu.addEventListener('click', (e) => {
    const item = e.target.closest('[data-export]');
    if (!item) return;
    closeExportMenu();
    if (item.dataset.export === 'doc') exportDoc();
    else if (item.dataset.export === 'lex') exportLexicon();
    else if (item.dataset.export === 'img') exportImage();
    else exportReport();
  });

  /* 编辑器快捷键 */
  codeInput.addEventListener('keydown', (e) => {
    const combo = comboFromEvent(e);
    const action = combo && actionForCombo(combo);
    if (action) {
      e.preventDefault();
      runAction(action);
      return;
    }
    /* 字号加减（Ctrl + / Ctrl - / Ctrl 0）；用户自定义了同组合键时让位给上面的自定义动作 */
    if ((e.ctrlKey || e.metaKey) && !e.altKey && (e.key === '=' || e.key === '+')) { e.preventDefault(); applyEditorSize(state.edSize + 1); return; }
    if ((e.ctrlKey || e.metaKey) && !e.altKey && e.key === '-') { e.preventDefault(); applyEditorSize(state.edSize - 1); return; }
    if ((e.ctrlKey || e.metaKey) && !e.altKey && e.key === '0') { e.preventDefault(); applyEditorSize(14); return; }
    if (acState.open) {
      /* Tab 采纳、Alt+↑↓ 换项、Esc 关闭；其余按键（含 ↑↓、Enter）一律不拦截，
         方向键照常移动光标，补全面板随光标自动跟随 / 关闭（selectionchange → scheduleAc） */
      if (e.key === 'Tab' && !e.shiftKey) { e.preventDefault(); acceptAc(acState.items[acState.active].term); return; }
      if (e.key === 'Escape') { e.preventDefault(); closeAc(); return; }
      if (e.altKey && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
        e.preventDefault();
        moveAc(e.key === 'ArrowDown' ? 1 : -1);
        return;
      }
    }
    if (e.key === 'Tab' && !e.shiftKey) { e.preventDefault(); execInsert('  '); }
  });

  /* 全局快捷键 */
  document.addEventListener('keydown', (e) => {
    /* 快捷键录制中：拦截一切按键 */
    if (capturingAction && dlgKeys.open) {
      e.preventDefault();
      e.stopPropagation();
      if (e.key === 'Escape') { cancelCapture(); return; }
      const combo = comboFromEvent(e);
      if (combo) {
        const act = capturingAction;
        capturingAction = null;
        assignKey(act, combo);
      }
      return;
    }
    if (e.key === 'F1') { e.preventDefault(); dlgHelp.showModal(); return; }
    if (e.key === 'Escape' && dlgHelp.open) { dlgHelp.close(); return; }
    if (e.key === 'Escape' && dlgRules.open) { dlgRules.close(); return; }
    const combo = comboFromEvent(e);
    const action = combo && actionForCombo(combo);
    if (action) {
      const inEditable = e.target instanceof HTMLElement &&
        (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA');
      /* 编辑器之外（如词库搜索框）不响应编辑类快捷键 */
      if (inEditable && e.target !== codeInput && (action === 'autocomplete' || action === 'toggleComment' || action === 'builder')) return;
      e.preventDefault();
      runAction(action);
    }
  }, true);

  window.addEventListener('resize', () => { closeAc(); syncScroll(); });
  window.addEventListener('beforeunload', () => { clearTimeout(saveTimer); save(); });
}

/* ==================== 初始化 ==================== */
function init() {
  const migrated = loadProjects();           /* 项目列表（首次会把旧 lexicode.v1 迁入默认项目并冻结） */
  loadPrefs();                               /* 全局偏好：主题 / 强调色 / 字体 / 字号 */
  const hadState = loadCurrentProject();     /* 当前项目的内容 + 词库 + 模式 */
  if (!hadState && !migrated) loadDemo();
  console.info(`[词条工坊] 启动 · 内置字体数据: ${typeof BUILTIN_FONT_DATA === 'undefined' ? '未加载（fonts-data.js 缺失或页面未刷新）' : `已加载 ${BUILTIN_FONTS.length} 款`} · 协议: ${location.protocol}`);
  loadRules();
  loadBindings();
  applyTheme(state.theme);
  updatePanelAlphaUi();
  restoreFonts();
  restoreBg();
  applyEditorSize(state.edSize, true);
  setMode(state.mode, true);
  rebuildIndex();
  renderLexicon();
  readMetrics();
  bindBuilderEvents();
  bindEvents();
  updateProjUi();
  analyze();
  renderAll();
  renderRulesToggles();
  renderSymbolDocs();
  renderKeys();
  renderHelpKeys();
  setSaveState('saved');
  codeInput.focus();
  if (!hadState) showToast('已载入示例：左侧为词库，红色为未收录内容，可导入自己的 TXT 词库', { duration: 6000 });
  else if (!lexSet.size) showToast('词库为空：可点击左侧“导入 TXT”或直接添加词条', { duration: 5000 });
  /* 空闲时预热内置字体解码，首次打开字体列表预览即可用（字体已内嵌，file:// 打开同样有效） */
  setTimeout(() => { for (const f of BUILTIN_FONTS) { try { document.fonts.load(`16px "${f.family}"`, '词条'); } catch { /* 忽略 */ } } }, 2000);
}

init();
